<?php
include("connection.php");
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$qry=mysql_query("delete from form where id='$id'");
	
	
	if($qry)
	{
			echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Successfully Deleted')
        window.location.href='file_search.php'
        </SCRIPT>");
		
	}
	else
	{
		print mysql_error();
		echo '<br> incorrect serial no! <br><br>';
		echo '<a href="file_search.php">Click here to go Back!</a>';
	}
}else
{
	echo '<br> 404 ERROR ! Page Not found. <br><br>';
	echo '<a href="file_search.php">Click here to go Back!</a>';
}
?>