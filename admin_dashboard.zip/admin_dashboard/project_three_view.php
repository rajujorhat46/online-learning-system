<?php
session_start();
error_reporting(0);
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='https://www.rohinimundra.com/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

  
  
    include_once "connection.php";
    if(isset($_GET['id']))
	{
		$id=$_GET['id'];
			  
			  $result=mysql_query("select * from project_three",$con);
			  $count=mysql_num_rows($result);
			  
			  if($count>0)
			  {
				  while($row=mysql_fetch_assoc($result))
				  {
				  
					  
			  $id=$row['id'];
			  $certainity_one=$row['certainity_one'];
			  $certainity_two=$row['certainity_two'];
			  $significance_one=$row['significance_one'];
			  $significance_two=$row['significance_two'];
			  $connection_one=$row['connection_one'];
			  $connection_two=$row['connection_two'];
			  $variety_one=$row['variety_one'];
			  $variety_two=$row['variety_two'];
			  $growth_one=$row['growth_one'];
			  $growth_two=$row['growth_two'];
			  $action_one=$row['action_one'];
			  $relation_one=$row['relation_one'];
			  $identity_one=$row['identity_one'];
			  $action_two=$row['action_two'];
			  $relation_two=$row['relation_two'];
			  $identity_two=$row['identity_two'];
			  $action_three=$row['action_three'];
			  $relation_three=$row['relation_three'];
			  $identity_three=$row['identity_three'];
			  $action_four=$row['action_four'];
			  $relation_four=$row['relation_four'];
			  $identity_four=$row['identity_four'];
			  $action_five=$row['action_five'];
			  $relation_five=$row['relation_five'];
			  $identity_five=$row['identity_five'];
			  $action_six=$row['action_six'];
			  $relation_six=$row['relation_six'];
			  $identity_six=$row['identity_six'];
			  
			 
			 
		
				  }
			  }else
			  {
			  	echo 'Wrong Input. try again later!! . :( <br><br>';
				echo '<a href="project_three_file.php">Click here to go Back!</a>';
				die();
			  }
	}else
	{
		
		
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin - Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
<script>
        function enableButton2() {
            document.getElementById("button2").disabled = false;
        }
    </script>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

.button {
    background-color: #51A351; 
    border: none;
    color: white;
    padding: 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button1 {border-radius: 4px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 4px;}
.button4 {border-radius: 4px;}
.button5 {border-radius: 4px;}
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>   <?php
					      $username=$_SESSION['login']  
					     ?>
  <span class="text">Welcome  <?php echo $username;?></span><b class="caret"> </b></a>
       
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
   <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
  
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Upload File</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="admin_ebook.php">Upload Ebook</a></li>
        <li><a href="admin_video.php">Upload Video</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project One</span> <span class="label label-important"></span></a>
      <ul>
       <li><a href="project_one_month_one_file.php">One Month Level</a></li>
        <li><a href="project_one_month_two_file.php">Two Month Level</a></li>
        <li><a href="project_one_month_three_file.php">Three Month Level</a></li>
       
      </ul>
        
           <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_two_file.php">Project Two</a></li>
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three_file.php">Project Three</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
        <li><a href="bonus_project_one_file.php">Bonus Project One File</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
        <li><a href="bonus_project_two_file.php">Bonus Project Two File</a></li>
        
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
     <li><a href="bonus_project_three_file.php">Bonus Project Three  File</a></li>
        
      </ul>
    </li>
    
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Four</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_four_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_four_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_four_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_four_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_four_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_four_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Five</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_five_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_five_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_five_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_five_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_five_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_five_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> </a></div>
  <h1>Project III – Rewrite your New Code</h1>
  <p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px;" align="justify">I. Look into each of your Buckets and write down the beliefs you need to positively fill that bucket.</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px;" align="justify">II. After the new belief is written, write down the  emotional state you need to be in to fill the bucket</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px;" align="justify">III.	At the  start of everyday practice the incantations and power emotions to fill the bucket for a better life and state of mind.</p>

</div>
<div class="container-fluid">
  <hr>
  

 <div class="row-fluid">
 <p style="font-size:24px; color:#000;">PART 1</p> 
<form class="form-horizontal" role="form"  method="post" action="">

    <div class="span12">
      <div class="widget-box">
       
        

        <div class="widget-content nopadding">
         
           <div style="overflow-x:auto;">
 
    <table border="1">
  <tr style="background-color:#666;">
      <th style="font-size:32px; font-weight:600; color:#000; padding-top:20px; padding-bottom:20px;">Buckets</th>
      <th style="font-size:32px; font-weight:600; color:#000;  padding-top:20px; padding-bottom:20px;">Beliefs/ Incantations</th>
      <th style="font-size:32px; font-weight:600; color:#000;  padding-top:20px; padding-bottom:20px;">Power Emotions</th>
    </tr>
    <tr>
      <th style="font-size:32px; font-weight:600; color:#000; padding-top:20px; padding-bottom:20px;"></th>
      <th style="font-size:18px; font-weight:100; color:#000;  padding-top:20px; padding-bottom:20px;">What belief do I need to adopt or remember in order to meet this need now</th>
      <th style="font-size:18px; font-weight:100; color:#000;  padding-top:20px; padding-bottom:20px;">What emotional state could I put myself into that would immediately fulfill this need </th>
    </tr>
   
   
      <tr>
      <td width="50" style="color:#000; "><p style="font-size:18px;">Certainity</p> </td>
   <td width="160px"><textarea class="span11" name="certainity_one" placeholder="Write your answer here"><?php echo $certainity_one;?></textarea></td>
      <td width="160px"><textarea class="span11" name="certainity_two" placeholder="Write your answer here" ><?php echo $certainity_two;?></textarea></td>
     </tr>
      
      <tr>
      <td style="color:#000; " width="px"><p style="font-size:18px;">Significance</p> </td>
      <td width="170px"><textarea class="span11" name="significance_one" placeholder="Write your answer here"><?php echo $significance_one;?></textarea> </td>
      <td width="100px"><textarea class="span11" name="significance_two" placeholder="Write your answer here" ><?php echo $significance_two;?></textarea></td>
     </tr>
      
     
      <tr>
      <td style="color:#000; " width="px"><p style="font-size:18px;">Love and Connection</p> </td>
      <td width="170px"><textarea class="span11" name="connection_one" placeholder="Write your answer here"><?php echo $connection_one;?></textarea> </td>
      <td width="100px"><textarea class="span11" name="connection_two" placeholder="Write your answer here" ><?php echo $connection_two;?></textarea></td>
     </tr>
     
     
      <tr>
      <td style="color:#000; " width="px"><p style="font-size:18px;">Contribution</p> </td>
      <td width="170px"><textarea class="span11" name="contribution_one" placeholder="Write your answer here"><?php echo $contribution_one;?></textarea> </td>
      <td width="100px"><textarea class="span11" name="contribution_two" placeholder="Write your answer here" ><?php echo $contribution_two;?></textarea></td>
     </tr>
      <tr>
      <td style="color:#000; " width="px"><p style="font-size:18px;">Variety</p> </td>
      <td width="170px"><textarea class="span11" name="variety_one" placeholder="Write your answer here"><?php echo $variety_one;?></textarea> </td>
      <td width="100px"><textarea class="span11" name="variety_two" placeholder="Write your answer here" ><?php echo $variety_two;?></textarea></td>
     </tr>
     <tr>
      <td style="color:#000; " width="px"><p style="font-size:18px;">Growth</p> </td>
      <td width="170px"><textarea class="span11" name="growth_one" placeholder="Write your answer here"><?php echo $growth_one;?></textarea> </td>
      <td width="100px"><textarea class="span11" name="growth_two" placeholder="Write your answer here" ><?php echo $growth_two;?></textarea></td>
     </tr>
     
 </table><br><br><br>
 <div>
 <p style="font-size:26px; color:#000; padding-left:15px;">PART II</h1><br>
 <p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px;" align="justify">I.	Look into each of your Buckets and write down the actions you need to take to positively fill that bucket.</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px;" align="justify">II.	Look into each of your Buckets and write down the person you need to connect with to positively fill that bucket.</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px;" align="justify">III. Make a note of the person you are being when you are filling the bucket</p>
 <p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px;" align="justify">IV.	Repeat this everyday to until you sunconsciously make this a daily practice and notice it impacting every area of your life positively</p>
 
 </div>
  <table border="1">
  <tr style="background-color:#666;">
      <th style="font-size:32px; font-weight:600; color:#000; padding-top:20px; padding-bottom:20px;">Action/Activities</th>
      <th style="font-size:32px; font-weight:600; color:#000;  padding-top:20px; padding-bottom:20px;">Relationship</th>
      <th style="font-size:32px; font-weight:600; color:#000;  padding-top:20px; padding-bottom:20px;">Identity</th>
    </tr>
    <tr>
      <th style="font-size:18px; font-weight:100; color:#000; padding-top:20px; padding-bottom:20px;">What action can I take or activity can I engage into to immediately fill this bucket?</th>
      <th style="font-size:18px; font-weight:100; color:#000;  padding-top:20px; padding-bottom:20px;">Who can I connect with to immediately fill this bucket?</th>
      <th style="font-size:18px; font-weight:100; color:#000;  padding-top:20px; padding-bottom:20px;">What kind of person am I being when I am filling this bucket?</th>
    </tr>
   
   
      <tr>
      <td width="160px"><textarea class="span11" name="action_one" placeholder="Write your answer here"><?php echo $action_one;?></textarea></td>
      <td width="160px"><textarea class="span11" name="relation_one" placeholder="Write your answer here"><?php echo $relation_one;?></textarea> </td>
      <td width="160px"><textarea class="span11" name="identity_one" placeholder="Write your answer here" ><?php echo $identity_one;?></textarea></td>
     </tr>
      
      <tr>
       <td width="160px"><textarea class="span11" name="action_two" placeholder="Write your answer here"><?php echo $action_two;?></textarea></td>
      <td width="160px"><textarea class="span11" name="relation_two" placeholder="Write your answer here"><?php echo $relation_two;?></textarea> </td>
      <td width="160px"><textarea class="span11" name="identity_two" placeholder="Write your answer here" ><?php echo $identity_two;?></textarea></td>
     </tr>
      
     
      <tr>
      <td width="160px"><textarea class="span11" name="action_three" placeholder="Write your answer here"><?php echo $action_three;?></textarea></td>
      <td width="160px"><textarea class="span11" name="relation_three" placeholder="Write your answer here"><?php echo $relation_three;?></textarea> </td>
      <td width="160px"><textarea class="span11" name="identity_three" placeholder="Write your answer here" ><?php echo $identity_three;?></textarea></td>
     </tr>
     
     
      <tr>
       <td width="160px"><textarea class="span11" name="action_four" placeholder="Write your answer here"><?php echo $action_four;?></textarea></td>
      <td width="160px"><textarea class="span11" name="relation_four" placeholder="Write your answer here"><?php echo $relation_four;?></textarea> </td>
      <td width="160px"><textarea class="span11" name="identity_four" placeholder="Write your answer here" ><?php echo $identity_four;?></textarea></td>
     </tr>
      <tr>
       <td width="160px"><textarea class="span11" name="action_five" placeholder="Write your answer here"><?php echo $action_five;?></textarea></td>
      <td width="160px"><textarea class="span11" name="relation_five" placeholder="Write your answer here"><?php echo $relation_five;?></textarea> </td>
      <td width="160px"><textarea class="span11" name="identity_five" placeholder="Write your answer here" ><?php echo $identity_five;?></textarea></td>
     </tr>
     <tr>
      <td width="160px"><textarea class="span11" name="action_six" placeholder="Write your answer here"><?php echo $action_six;?></textarea></td>
      <td width="160px"><textarea class="span11" name="relation_six" placeholder="Write your answer here"><?php echo $relation_six;?></textarea> </td>
      <td width="160px"><textarea class="span11" name="identity_six" placeholder="Write your answer here" <?php echo $identity_six;?>></textarea></td>
     </tr>
     
 </table>
</div>
             
              
             
               <div class="controls"  style="margin-left:10px;">
   <!--<button type="submit" class="btn btn-success" name="submit" >Save</button>-->
   </form>
  
              
              </div>
            </div>
            </div></div></div>
     
     
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
