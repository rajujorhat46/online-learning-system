<?php
session_start();
error_reporting(0);
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='https://www.rohinimundra.com/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

  
  
    include_once "connection.php";
    if(isset($_GET['s_no']))
	{
		$s_no=$_GET['s_no'];
			  
			  $result=mysql_query("select * from bonus_project_five_day_two ",$con);
			  $count=mysql_num_rows($result);
			  
			  if($count>0)
			  {
				  while($row=mysql_fetch_assoc($result))
				  {
					  
					  
					  
			  $s_no=$row['s_no'];
			  $situation=$row['situation'];
			  $cause=$row['cause'];
			  $elp_changed=$row['elp_changed'];
			  $outcomes=$row['outcomes'];
			  
			 
			 
		
				  }
			  }else
			  {
			  	echo 'Wrong Input. try again later!! . :( <br><br>';
				echo '<a href="bonus_project_five_day_two_file.php">Click here to go Back!</a>';
				die();
			  }
	}else
	{
		
		
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>   <?php
					      $username=$_SESSION['login']  
					     ?>
  <span class="text">Welcome  <?php echo $username;?></span><b class="caret"> </b></a>
       
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="customer.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
      <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Upload File</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="admin_ebook.php">Upload Ebook</a></li>
        <li><a href="admin_video.php">Upload Video</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project One</span> <span class="label label-important"></span></a>
      <ul>
       <li><a href="project_one_month_one_file.php">One Month Level</a></li>
        <li><a href="project_one_month_two_file.php">Two Month Level</a></li>
        <li><a href="project_one_month_three_file.php">Three Month Level</a></li>
       
      </ul>
        
           <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_two_file.php">Project Two</a></li>
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three_file.php">Project Three</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
        <li><a href="bonus_project_one_file.php">Bonus Project One File</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
        <li><a href="bonus_project_two_file.php">Bonus Project Two File</a></li>
        
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
     <li><a href="bonus_project_three_file.php">Bonus Project Three  File</a></li>
        
      </ul>
    </li>
    
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Four</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_four_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_four_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_four_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_four_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_four_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_four_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Five</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_five_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_five_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_five_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_five_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_five_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_five_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i></a></div>
  <h1>Bonus Project Five – Change your State - Fear</h1><br>
  <p style="font-size:18px; margin-left:20px; margin-right:10px;">I. Look into the mirror every morning for 5 minutes and have a conversation with yourself.</p>

  <p style="font-size:18px; margin-left:20px; margin-right:10px;">II. After the conversation, write down 5 Positive statements that you make to your self. (Eg: You are decisive, you are a great human being, you are full of gratitude, You are successful, You are wealthy etc)</h1>
  <p style="font-size:18px; margin-left:20px; margin-right:10px;">III. At the end of the day, key down the 5 impact this has had on you today.</h1>
</div>
<div class="container-fluid">
  <hr>
    <button class="button button1"><a style="color:#FFF;" href="bonus_project_five_day_one_file.php">Day One</a></button>
<button class="button button2"><a style="color:#FFF;" href="bonus_project_five_day_two_file.php">Day Two</a></button>
<button class="button button3"><a style="color:#FFF;" href="bonus_project_five_day_three_file.php">Day Three</a></button>
<button class="button button4"><a style="color:#FFF;" href="bonus_project_five_day_four_file.php">Day Four</a></button>
<button class="button button5"><a style="color:#FFF;" href="bonus_project_five_day_five_file.php">Day Five</a></button>
<button class="button button5"><a style="color:#FFF;" href="bonus_project_five_day_six_file.php">Day Six</a></button>
<button class="button button5"><a style="color:#FFF;" href="bonus_project_five_day_seven_file.php">Day Seven</a></button>
  <div class="row-fluid">
  
<form class="form-horizontal" role="form"  method="post" action="bonus_project_five_day_two_update.php" onSubmit="return check();">

    <div class="span12">
      <div class="widget-box">
       
        
        <div class="widget-content nopadding">
         
           <div style="overflow-x:auto;">
  <table border="1">
  <p style="font-size:18px; padding-top:5px; padding-bottom:5px; margin-left:10px; margin-right:10px; color:#000; font-weight:600;">Day 2:  Record the impact your new codes have had using ELP to overcome Fear.</p>
 <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">1.	Situation </td>
      <td><textarea class="span11" name="situation" ><?php echo $situation;?></textarea></td>
     
     </tr>
      <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">2.	Cause </td>
      <td><textarea class="span11" name="cause" ><?php echo $cause;?></textarea></td>
      
     </tr>
      <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">3. ELP Changed</td>
      <td><textarea class="span11" name="elp_changed" ><?php echo $elp_changed;?></textarea></td>
   
     </tr>
      <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">4.	Outcome </td>
      <td><textarea class="span11" name="outcomes" ><?php echo $outcomes;?></textarea></td>
     <input type="hidden" name="s_no" id="s_no" value="<?php echo $s_no;?>">
     </tr>
     
     </table><br><br>
 </div>
 <div class="controls"  style="margin-left:10px;">
<button type="submit" class="btn btn-success" name="submit">Save</button>
              </div>
            </div>
            </div></div></div>
      </div>
    </div>
  </div>
 
</div></div>
</form>








<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
