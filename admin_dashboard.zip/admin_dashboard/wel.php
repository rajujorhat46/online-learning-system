<?php
session_start();
$username=$_SESSION['login'];
include("connection.php");
extract($_POST);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
}

/* Create three equal columns that floats next to each other */
.column {
	margin-left:40px;
	margin-top: 20px;
    width: 55%;
    padding: 10px;
    height: 300px; /* Should be removed. Only for demonstration */
}
.column1 {
	margin-top:-160px;
	margin-left:800px;
    width: 40%;
    padding: 10px;
    height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}
</style>
</head>
<body>

<div class="row">
  <div class="column">
   
     <?php
			 
			  
			$result=mysql_query("SELECT * FROM form where login='$username'");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
  		<p align="" style="font-size:42px; font-family: angel_tears;  font-style:italic; ">Welcome <?php echo $row["name"];?></p>
           
			 <?php
				  }
			  }
		
		  ?>	<!--<h3 id="description_subtitle">Mindshift Coach | Facilitator | Speaker</h3>-->
				<p style="font-size:22px; font-family: angel_tears; font-style:italic; ">I am thrilled about your commitment to become a stronger, better and a newer YOU!<br />
				When I was going through the struggles of my life, I had a strong support system that helped me find my way
to success and guide me into experiencing the true freedom life had in store for me. I now know the importance of
having that support and a system to overcome challenges and so I cannot wait to share this secret with you
because of how simple it is and it WORKS!!!</p>
<p id="description_text" style="font-size:22px; font-family: angel_tears ;  font-style:italic; ">Do you feel like you are meant to do more in life?<br>
Do you have dreams that need a direction?<br>
Do you want to know the secret to living a life of abundance and experiencing the best?<br>
Are you ready to take the big leap? Are you ready to move forward?</p>
<p id="description_text" style="font-size:22px; font-family: 'angel_tears';  font-style:italic; ">If Yes, then you at the right place.</p>
<p id="description_text" style="font-size:22px; font-family: 'angel_tears';  font-style:italic; ">- Rohini Mundra</p>
  </div>
  <div class="column1">
   
     <img src="img/qw-600x640.jpg" style="width:450px; height:370px;" ><br><br><br>
		<a href="terms.html" style="font-weight:600; color:#FFF; margin-left:150px;"><input type="button" value="OK" style="padding-top:5px; padding-bottom:5px; background-color:#F90; width:200px; font-weight:600;"></a>
  </div>
  
</div>



</body>
</html>
