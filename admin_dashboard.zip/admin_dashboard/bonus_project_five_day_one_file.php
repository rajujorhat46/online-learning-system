<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='https://www.rohinimundra.com/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin - Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="datatable/jquery.dataTables.min.css">

<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
<script>
        function enableButton2() {
            document.getElementById("button2").disabled = false;
        }
    </script>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>   <?php
					      $username=$_SESSION['login']  
					     ?>
  <span class="text">Welcome  <?php echo $username;?></span><b class="caret"> </b></a>
       
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
     <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
  
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Upload File</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="admin_ebook.php">Upload Ebook</a></li>
        <li><a href="admin_video.php">Upload Video</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project One</span> <span class="label label-important"></span></a>
      <ul>
       <li><a href="project_one_month_one_file.php">One Month Level</a></li>
        <li><a href="project_one_month_two_file.php">Two Month Level</a></li>
        <li><a href="project_one_month_three_file.php">Three Month Level</a></li>
       
      </ul>
        
           <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_two_file.php">Project Two</a></li>
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three_file.php">Project Three</a></li>
      </ul>
    </li>
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
         <li><a href="bonus_project_one_file.php">Bonus Project One File</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
         <li><a href="bonus_project_two_file.php">Bonus Project Two File</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
         <li><a href="bonus_project_three_file.php">Bonus Project Three File</a></li>
       
      </ul>
    </li>
    
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Four</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_four_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_four_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_four_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_four_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_four_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_four_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Five</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_five_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_five_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_five_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_five_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_five_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_five_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i></a></div>
  <h1>Bonus Project Five : Change your State - Fear</h1>
</div>
<div class="container-fluid">
<div style="margin-left:50px; width:90%;">
<table border="1" class="table table-bordered data-table" id="order_details" style="margin-left:20px; margin-top:30px;">
<thead>
<tr>
<th><a href="#" class="">S.No.</a></th>
<th scope="col"><a href="#" class="">SITUATION</a></th>
<th scope="col"><a href="#" class="">CAUSE</a></th>
<th scope="col"><a href="#" class="">ELP CHANGED</a></th>
<th scope="col"><a href="#" class="">User</a></th>
<th scope="col"><a href="#" class="sort-by">Action</a></th>
</tr>
</thead>
<tbody>
 <?php
			  include_once "connection.php";
			  
			$result=mysql_query("select * from bonus_project_five_day_one");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
<tr>
<td align="center"><?php echo $row["s_no"];  ?></td>
<td><?php echo $row["situation"];  ?></td>
<td><?php echo $row["cause"];  ?></td>
<td><?php echo $row["elp_changed"];  ?></td>
<td><?php echo $row["login"];  ?></td>
<?php 
echo' <td align="center"><a href="bonus_project_five_day_one_view.php? s_no='. $row['s_no'] . '">  <button type="button" >View</button> </a>';
		
		 ?>


         </td>
                <?php
				  }
			  }
	      
		  ?>

</tr>


</tbody>
</table></div></div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
 <script type="text/javascript" src="datatable/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="datatable/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
       $('#order_details').DataTable({
            "lengthMenu": [[10,50, 100, 500, -1], [10,50, 100, 500, "All"]],
            "iDisplayLength": 10
        });
    </script>
</body>
</html>
