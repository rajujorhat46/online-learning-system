
<?php
include("connection.php");
extract($_POST);
$hash = md5( rand(0,1000) ); 
$password = rand(1000,5000); 

$qry=mysql_query("insert into form (name,phone,email,signup_date,location,duration,payment_type,comments,batch_no,payment_one,payment_one_date,payment_two,payment_two_date,payment_three,payment_three_date,hash) values('$name','$phone','$email','$signup_date','$location','$duration','$payment_type','$comments','$batch_no','$payment_one','$payment_one_date','$payment_two','$payment_two_date','$payment_three','$payment_three_date','$hash')");
if($qry)
{
  
}
else
{
	print mysql_error();
}

 $last_id=mysql_insert_id();
  extract($_POST);
 $count=count($payment_type1);
for ($i=0; $i < $count; $i++) {
 
 $qry3="INSERT into paymentdate (payment_type1,payment_date,cert_id) values ('$payment_type1[$i]','$payment_date[$i]','$last_id')";

$qry2=mysql_query($qry3);

 
  echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Successfully Inserted')
        window.location.href='http://www.rohinimundra.com/admin_dashboard/file_search.php'
        </SCRIPT>");	

}

?>
