<?php
include("connection.php");
extract($_POST);
$qry=mysql_query("update form SET name='$name',phone='$phone',login='$login', signup_date='$signup_date',location='$location',duration='$duration',payment_type='$payment_type',comments='$comments',batch_no='$batch_no',payment_one='$payment_one',payment_one_date='$payment_one_date',payment_two='$payment_two',payment_two_date='$payment_two_date',payment_three='$payment_three',payment_three_date='$payment_three_date' where s_no='$s_no'")or die(mysql_error());
if($qry)
{
    
}
else
{
	print mysql_error();
}
$last_id=mysql_insert_id();
extract($_POST);
$count=count($payment_type1);
for ($i=0; $i < $count; $i++) { 


$jjj = $payment_type1[$i];
$sss = $payment_date[$i];
$mm_id = $tfive_id[$i];


//echo "TF " . $textfield . "<br />";

$qry3SQL = "update paymentdate SET payment_type1='$jjj', payment_date='$sss' where s_no='$mm_id'";
//echo $qry3SQL . "<br />";
   $qry3 =mysql_query($qry3SQL); 
	 echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Yoy Had Successfully Updated Data')
        window.location.href='file_search.php'
        </SCRIPT>");


}



?>
