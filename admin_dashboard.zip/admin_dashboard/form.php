<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='http://www.rohinimundra.com/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin - Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery-latest.js"></script>

</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
   
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project One</span> <span class="label label-important"></span></a>
      <ul>
       <li><a href="project_one_month_one_file.php">One Month Level</a></li>
        <li><a href="project_one_month_two_file.php">Two Month Level</a></li>
        <li><a href="project_one_month_three_file.php">Three Month Level</a></li>
       
      </ul>
        
           <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_two_file.php">Project Two</a></li>
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three_file.php">Project Three</a></li>
      </ul>
    </li>
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
        <li><a href="bonus_project_one_file.php">Bonus Project One File</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
        <li><a href="bonus_project_two_file.php">Bonus Project Two File</a></li>
        
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
     <li><a href="bonus_project_three_file.php">Bonus Project Three  File</a></li>
        
      </ul>
    </li>
    
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Four</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_four_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_four_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_four_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_four_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_four_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_four_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Five</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_five_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_five_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_five_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_five_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_five_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_five_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>
 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  <h1>Fill-up the form correctly</h1>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
  <form class="form-horizontal" role="form" method="post" action="" onSubmit="return check();">

    <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
         
        </div> 
        
        <div class="widget-content nopadding">
         
            <div class="control-group">
              <label class="control-label">Name : <span class="require">*</span></label>
              <div class="controls">
                
                  <input type="text" class="span11" id="name" name="name" placeholder="Name" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Phone : <span class="require">*</span></label>
              <div class="controls">
               <input type="number" class="span11" id="phone" name="phone" required placeholder="Phone">
                
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Email : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="email" class="span11" id="login" name="login" placeholder="Enter Email Id" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Sign Up Date : <span class="require">*</span></label>
              <div class="controls">
               
                <input type="date" class="span11" id="signup_date" name="signup_date" value="<?php echo date("Y-m-d") ?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Location : <span class="require">*</span></label>
              <div class="controls">
               
                 <select name="location" id="location">
           <option></option>
          <option value="Bangalore">Bangalore</option>
          <option value="Pune">Pune</option>
            <option value="Hyderabad">Hyderabad</option>
            <option value="Chennai">Chennai</option>
             <option value="Mumbai">Mumbai</option>
           </select>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Duration : <span class="require">*</span></label>
              <div class="controls">
               
                <select class="" name="duration" id="duration" required>
           <option></option>
          <option value="3 Days Program">3 Days Program</option>
          <option value="3 Months Program">3 Months Program</option>
           <option value="6 Months Program">6 Months Program</option>
         
           </select>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Payment Type : <span class="require">*</span></label>
              <div class="controls">
               <select name="payment_type" id="payment_type">
           <option></option>
          <option value="Single">Single</option>
          <option value="Multiple">Multiple</option>
           </select>
              </div>
            </div>
            
             <div class="control-group">
              <label class="control-label">Comments : <span class="require">*</span></label>
              <div class="controls">
           <textarea style="width:86%;" name="comments" id="comments"></textarea>
              </div>
            </div>
            
            
             </div></div></div>
     
     <div class="span6">
     <div class="widget-box">
     <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          
        </div>
        <div class="widget-content nopadding">
        
        
        <div class="control-group">
              <label class="control-label">Batch Number : <span class="require">*</span></label>
              <div class="controls"  style="width:57%;">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" class="span11" id="batch_no" name="batch_no" required>
               
              </div>
            </div>

        <div class="control-group">
              <label class="control-label"> Payment Part One : <span class="require">*</span></label>
              <div class="controls" style="margin-right:30px;">
                
                 INR <input type="number" class="span11" id="payment_one" name="payment_one" value="0" required onkeypress='validate(event)' style="margin-right:0px;" onkeyup="word.innerHTML=convertNumberToWords(this.value)" >
                
<div id="word"></div>
<script>
function convertNumberToWords(amount) {
    var words = new Array();
    words[0] = '';
    words[1] = 'One';
    words[2] = 'Two';
    words[3] = 'Three';
    words[4] = 'Four';
    words[5] = 'Five';
    words[6] = 'Six';
    words[7] = 'Seven';
    words[8] = 'Eight';
    words[9] = 'Nine';
    words[10] = 'Ten';
    words[11] = 'Eleven';
    words[12] = 'Twelve';
    words[13] = 'Thirteen';
    words[14] = 'Fourteen';
    words[15] = 'Fifteen';
    words[16] = 'Sixteen';
    words[17] = 'Seventeen';
    words[18] = 'Eighteen';
    words[19] = 'Nineteen';
    words[20] = 'Twenty';
    words[30] = 'Thirty';
    words[40] = 'Forty';
    words[50] = 'Fifty';
    words[60] = 'Sixty';
    words[70] = 'Seventy';
    words[80] = 'Eighty';
    words[90] = 'Ninety';
    amount = amount.toString();
    var atemp = amount.split(".");
    var number = atemp[0].split(",").join("");
    var n_length = number.length;
    var words_string = "";
    if (n_length <= 9) {
        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
        var received_n_array = new Array();
        for (var i = 0; i < n_length; i++) {
            received_n_array[i] = number.substr(i, 1);
        }
        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
            n_array[i] = received_n_array[j];
        }
        for (var i = 0, j = 1; i < 9; i++, j++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                if (n_array[i] == 1) {
                    n_array[j] = 10 + parseInt(n_array[j]);
                    n_array[i] = 0;
                }
            }
        }
        value = "";
        for (var i = 0; i < 9; i++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                value = n_array[i] * 10;
            } else {
                value = n_array[i];
            }
            if (value != 0) {
                words_string += words[value] + " ";
            }
            if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Crores ";
            }
            if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Lakhs ";
            }
            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Thousand ";
            }
            if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                words_string += "Hundred and ";
            } else if (i == 6 && value != 0) {
                words_string += "Hundred ";
            }
        }
        words_string = words_string.split("  ").join(" ");
    }
    return words_string;
}
</script>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">First Payment Date : <span class="require">*</span></label>
              <div class="controls"  style="width:57%;">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" class="span11" id="payment_one_date" name="payment_one_date" value="<?php echo date("Y-m-d") ?>" required>
               
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Two :</label>
              <div class="controls" style="margin-right:30px;">
                 INR <input type="number" class="span11" id="payment_two" name="payment_two" onkeyup="words1.innerHTML=convertNumberToWords1(this.value)"  value="0">
                 
                 <div id="words1"></div>
<script>
function convertNumberToWords1(amount) {
    var words1 = new Array();
    words1[0] = '';
    words1[1] = 'One';
    words1[2] = 'Two';
    words1[3] = 'Three';
    words1[4] = 'Four';
    words1[5] = 'Five';
    words1[6] = 'Six';
    words1[7] = 'Seven';
    words1[8] = 'Eight';
    words1[9] = 'Nine';
    words1[10] = 'Ten';
    words1[11] = 'Eleven';
    words1[12] = 'Twelve';
    words1[13] = 'Thirteen';
    words1[14] = 'Fourteen';
    words1[15] = 'Fifteen';
    words1[16] = 'Sixteen';
    words1[17] = 'Seventeen';
    words1[18] = 'Eighteen';
    words1[19] = 'Nineteen';
    words1[20] = 'Twenty';
    words1[30] = 'Thirty';
    words1[40] = 'Forty';
    words1[50] = 'Fifty';
    words1[60] = 'Sixty';
    words1[70] = 'Seventy';
    words1[80] = 'Eighty';
    words1[90] = 'Ninety';
    amount = amount.toString();
    var atemp = amount.split(".");
    var number = atemp[0].split(",").join("");
    var n_length = number.length;
    var words1_string = "";
    if (n_length <= 9) {
        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
        var received_n_array = new Array();
        for (var i = 0; i < n_length; i++) {
            received_n_array[i] = number.substr(i, 1);
        }
        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
            n_array[i] = received_n_array[j];
        }
        for (var i = 0, j = 1; i < 9; i++, j++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                if (n_array[i] == 1) {
                    n_array[j] = 10 + parseInt(n_array[j]);
                    n_array[i] = 0;
                }
            }
        }
        value = "";
        for (var i = 0; i < 9; i++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                value = n_array[i] * 10;
            } else {
                value = n_array[i];
            }
            if (value != 0) {
                words1_string += words1[value] + " ";
            }
            if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                words1_string += "Crores ";
            }
            if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
                words1_string += "Lakhs ";
            }
            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
                words1_string += "Thousand ";
            }
            if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                words1_string += "Hundred and ";
            } else if (i == 6 && value != 0) {
                words1_string += "Hundred ";
            }
        }
        words1_string = words1_string.split("  ").join(" ");
    }
    return words1_string;
}
</script>
                 
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Second Payment Date :</label>
              <div class="controls"  style="width:57%;">
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" class="span11" id="payment_two_date" name="payment_two_date" value="<?php echo date("Y-m-d") ?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Three :</label>
              <div class="controls" style="margin-right:30px;">
                INR <input type="number" class="span11" id="payment_three" name="payment_three" onkeyup="words2.innerHTML=convertNumberToWords2(this.value)"  value="0">
                
                
                 <div id="words2"></div>
<script>
function convertNumberToWords2(amount) {
    var words2 = new Array();
    words2[0] = '';
    words2[1] = 'One';
    words2[2] = 'Two';
    words2[3] = 'Three';
    words2[4] = 'Four';
    words2[5] = 'Five';
    words2[6] = 'Six';
    words2[7] = 'Seven';
    words2[8] = 'Eight';
    words2[9] = 'Nine';
    words2[10] = 'Ten';
    words2[11] = 'Eleven';
    words2[12] = 'Twelve';
    words2[13] = 'Thirteen';
    words2[14] = 'Fourteen';
    words2[15] = 'Fifteen';
    words2[16] = 'Sixteen';
    words2[17] = 'Seventeen';
    words2[18] = 'Eighteen';
    words2[19] = 'Nineteen';
    words2[20] = 'Twenty';
    words2[30] = 'Thirty';
    words2[40] = 'Forty';
    words2[50] = 'Fifty';
    words2[60] = 'Sixty';
    words2[70] = 'Seventy';
    words2[80] = 'Eighty';
    words2[90] = 'Ninety';
    amount = amount.toString();
    var atemp = amount.split(".");
    var number = atemp[0].split(",").join("");
    var n_length = number.length;
    var words2_string = "";
    if (n_length <= 9) {
        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
        var received_n_array = new Array();
        for (var i = 0; i < n_length; i++) {
            received_n_array[i] = number.substr(i, 1);
        }
        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
            n_array[i] = received_n_array[j];
        }
        for (var i = 0, j = 1; i < 9; i++, j++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                if (n_array[i] == 1) {
                    n_array[j] = 10 + parseInt(n_array[j]);
                    n_array[i] = 0;
                }
            }
        }
        value = "";
        for (var i = 0; i < 9; i++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                value = n_array[i] * 10;
            } else {
                value = n_array[i];
            }
            if (value != 0) {
                words2_string += words2[value] + " ";
            }
            if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                words2_string += "Crores ";
            }
            if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
                words2_string += "Lakhs ";
            }
            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
                words2_string += "Thousand ";
            }
            if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                words2_string += "Hundred and ";
            } else if (i == 6 && value != 0) {
                words2_string += "Hundred ";
            }
        }
        words2_string = words2_string.split("  ").join(" ");
    }
    return words2_string;
}
</script>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Date Three :</label>
              <div class="controls"  style="width:57%;">
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" class="span11" id="payment_three_date" name="payment_three_date"  value="<?php echo date("Y-m-d") ?>" >
              </div>
            </div>
            
         
           <div id="main1" style="margin-left:10px;">
    <div class="my-form1">
            <p class="text-box1" style="font-size:14px; padding-top:10px;">
               Click Here To Add More Field : &nbsp; &nbsp; &nbsp; <button type="button" class="remove-field1"><a class="add-box1" href="#">+</a></button>
            </p>
            <div id="doc1"></div>
    </div>
</div>

         
          
        </div>
      </div>
         <script type="text/javascript">
var count=1;
jQuery(document).ready(function($){
    $('.my-form1 .add-box1').click(function(){
        var n = $('.text-box1').length + 1;
        if( 10 < n ) {
            alert('Stop it!');
            return false;
        }
		
		//var box_html = $('<table width="100" border="1" cellspacing="0" cellpadding="0">');
       // var box_html = $('<tr>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
       // var box_html = $('</tr>');
        //var box_html = $('</table>');
		//<a href="#" class="remove-box">Remove</a>

var box_html='';
box_html+='<div id="remove1">';
box_html+='<div class="control-group">';
box_html+='<input type="text" class="control-label" id="payment_type1[]" name="payment_type1[]" value=""  style="height:10px;" placeholder="Enter Payment Type">';
box_html+='<div class="controls"  style="width:57%; margin-top:-10px;">';
box_html+='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" class="span11" id="payment_date[]" name="payment_date[]"  value="<?php echo date("Y-m-d") ?>">';
box_html+='</div>';
box_html+='</div>';

box_html+='<label ><button type="button" id="remove_add1" class="remove-box1">Remove</button></label>';
//box_html+='<input type="text" class="input-block-level" name="textfield28" id="textfield28" required placeholder="">';
box_html+='</div>';
box_html+='</div>';
box_html+='</div>';

 //var box_html = $('<input type="text" name="boxes[]" value="" id="box' + n + '"/><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '"/><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><a href="#" class="remove-box">Remove</a></p>');
 //alert(box_html);
       // box_html.hide();
        //$('.my-form p.text-box:last').after(box_html);
		$('#doc1').append(box_html);
        //box_html.fadeIn('slow');
        return false;
    });
    $('.my-form1').on('click', '.remove-box1', function(){
		//alert('clicked');
        //$(this).parents('div').eq(1).css( 'background-color', '#FF6C6C' );
		//var raju=$(this).parents('#remove');
		//console.log(raju);
		//console.log($(this).parents('#remove'));
        $(this).parents('#remove1').fadeOut("slow", function() {
            $(this).empty();
			//alert('Removed Sucessfully');
            /*$('.box-number').each(function(index){
                $(this).text( index + 1 );
            });*/
        });
        return false;
    });
	$('#remove_add_raju1').click(function(){
		alert('REmoved.');
		$(this).parent('#remove1').hide();
	});
});
</script>  
     
             
<br> 
 <button type="submit" name="submit" id="submit" class="btn btn-success">Save</button>     
 </form>
  
      
   
      
        </div>
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 

 

<script>

</script>
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
<script type="text/javascript">
var count=1;
jQuery(document).ready(function($){
    $('.my-form1 .add-box1').click(function(){
        var n = $('.text-box1').length + 1;
        if( 10 < n ) {
            alert('Stop it!');
            return false;
        }
		
		//var box_html = $('<table width="100" border="1" cellspacing="0" cellpadding="0">');
       // var box_html = $('<tr>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
        //var box_html = $('<td><input type="text" name="boxes[]" value="" id="box' + n + '"/></td>');
       // var box_html = $('</tr>');
        //var box_html = $('</table>');
		//<a href="#" class="remove-box">Remove</a>

var box_html='';
box_html+='<div id="remove1">';
box_html+='<table width="752" border="1" cellpadding="0" cellspacing="0">';
box_html+='<tr>';

box_html+='<td width="144" style="font-weight:bold">Land</td>';
box_html+='<td width="144" style="font-weight:bold">Improvement</td>';
box_html+='<td width="144" style="font-weight:bold">Exemption</td>';
box_html+='<td width="144" style="font-weight:bold">Others</td>';
box_html+='<td width="445" style="font-weight:bold">Total</td>';
box_html+='</tr>';
box_html+='<tr>';
box_html+='<td><input type="text"  name="land1[]" id="land1[]" value="" style="text-align:justify; text-transform:uppercase;"></td>';
box_html+='<td><input type="text" name="improvement1[]" id="improvement1[]" value=""    style="text-align:justify; text-transform:uppercase;"></td>';
box_html+='<td><input type="text" name="exemption1[]" id="exemption1[]" value=""   style="text-align:justify; text-transform:uppercase;"></td>';
box_html+='<td><input type="text"  name="others1[]" id="others1[]" value=""   style="text-align:justify; text-transform:uppercase;"></td>';
box_html+='<td><input type="text"  name="total1[]" id="total1[]" value=""  style="text-align:justify; text-transform:uppercase;"></td>';

box_html+='</tr>';
box_html+='</table>';
box_html+='<label ><button type="button" id="remove_add1" class="remove-box1">Remove</button></label>';
//box_html+='<input type="text" class="input-block-level" name="textfield28" id="textfield28" required placeholder="">';
box_html+='</div>';
box_html+='</div>';
box_html+='</div>';

 //var box_html = $('<input type="text" name="boxes[]" value="" id="box' + n + '"/><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '"/><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><input type="text" name="boxes[]" value="" id="box' + n + '" /><a href="#" class="remove-box">Remove</a></p>');
 //alert(box_html);
       // box_html.hide();
        //$('.my-form p.text-box:last').after(box_html);
		$('#doc1').append(box_html);
        //box_html.fadeIn('slow');
        return false;
    });
    $('.my-form1').on('click', '.remove-box1', function(){
		//alert('clicked');
        //$(this).parents('div').eq(1).css( 'background-color', '#FF6C6C' );
		//var raju=$(this).parents('#remove');
		//console.log(raju);
		//console.log($(this).parents('#remove'));
        $(this).parents('#remove1').fadeOut("slow", function() {
            $(this).empty();
			//alert('Removed Sucessfully');
            /*$('.box-number').each(function(index){
                $(this).text( index + 1 );
            });*/
        });
        return false;
    });
	$('#remove_add_raju1').click(function(){
		alert('REmoved.');
		$(this).parent('#remove1').hide();
	});
});
</script>


<?php
include("connection.php");
$username=$_SESSION['login'];
$hash = md5( rand(0,1000) ); 
$password = rand(1000,5000); 	
if(isset($_POST['submit']))

{
extract($_POST);
$qry=mysql_query("insert into form (name,phone,login,signup_date,location,duration,payment_type,comments,batch_no,payment_one,payment_one_date,payment_two,payment_two_date,payment_three,payment_three_date,hash) values('$name','$phone','$login','$signup_date','$location','$duration','$payment_type','$comments','$batch_no','$payment_one','$payment_one_date','$payment_two','$payment_two_date','$payment_three','$payment_three_date','$hash')")or die(mysql_error());
if($qry)
{
	 
header('Location:project_one_month_one_view.php? id='. $row['id'] .'');	

}
	}
else
{
	print mysql_error();
	}
	 $last_id=mysql_insert_id();
  extract($_POST);
 $count=count($payment_type1);
for ($i=0; $i < $count; $i++) {
 

	 $qry3="INSERT into paymentdate (payment_type1,payment_date,cert_id) values ('$payment_type1[$i]','$payment_date[$i]','$last_id')";

$qry2=mysql_query($qry3);
echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Successfully Inserted')
        window.location.href='https://www.rohinimundra.com/admin_dashboard/form.php'
        </SCRIPT>");
}
	
	
?>        
</body>
</html>
