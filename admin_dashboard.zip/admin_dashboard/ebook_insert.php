 <?php
include("connection.php");
if(isset($_POST['submit']))
{
	function UploadOne($fname)
{
$uploaddir = 'upload/';
if (is_uploaded_file($fname['tmp_name']))
{
$filname = basename($fname['name']);
$uploadfile = $uploaddir . basename($fname['name']);
if (move_uploaded_file ($fname['tmp_name'], $uploadfile))
{
	
	
}
else
$res = "Could not move ".$fname['tmp_name']." to ".$uploadfile."<br>";
}
else
$res = "File ".$fname['name']." failed to upload.";

}
	
	if ($_FILES['picture']['name'] != "")	
{
$res = UploadOne($_FILES['picture']);
$filname = $_FILES['picture']['name'];
echo ($res);

}

	
		$dt = time();
		$ip = $_SERVER['REMOTE_ADDR'];
		$timezone = "Asia/Calcutta";
		if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
		$time=date('g:i a');
	

$details=$_POST["details"];



	{
$qry=mysql_query("insert into  upload_ebook(details,image_name) values('$details','$filname')");

	}
	
	$qry="<font color='green'>Notice added Successfully</font>";
	 echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Your file has been successfully updated THANK YOU')
        window.location.href='admin_ebook.php'
        </SCRIPT>");	
	}



?>       