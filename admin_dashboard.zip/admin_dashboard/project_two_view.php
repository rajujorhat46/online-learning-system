<?php
session_start();
error_reporting(0);
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an Admin. <a href='https://www.rohinimundra.com/admin_dashboard/admin_login.php'>Go to Login Page</a>";
	die();
}

  
  
    include_once "connection.php";
    if(isset($_GET['id']))
	{
		$id=$_GET['id'];
			  
			  $result=mysql_query("select * from project_two_step_one",$con);
			  $count=mysql_num_rows($result);
			  
			  if($count>0)
			  {
				  while($row=mysql_fetch_assoc($result))
				  
				  {
			  $id=$row['id'];
			  $details=$row['details'];
			  $image_name=$row['image_name'];
			  $url = $row["upload"]."/".$row["image_name"];
			  
			  
			 
		
				  }
			  }else
			  {
			  	echo 'Wrong Input. try again later!! . :( <br><br>';
				echo '<a href="project_one_month_one_file.php">Click here to go Back!</a>';
				die();
			  }
	}else
	{
		
		
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
<style>
.cc{
	margin-left:500px;}
</style>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
  <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
  
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Upload File</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="admin_ebook.php">Upload Ebook</a></li>
        <li><a href="admin_video.php">Upload Video</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project One</span> <span class="label label-important"></span></a>
      <ul>
       <li><a href="project_one_month_one_file.php">One Month Level</a></li>
        <li><a href="project_one_month_two_file.php">Two Month Level</a></li>
        <li><a href="project_one_month_three_file.php">Three Month Level</a></li>
       
      </ul>
        
           <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_two_file.php">Project Two</a></li>
       
       
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three_file.php">Project Three</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Four</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_four_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_four_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_four_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_four_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_four_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_four_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Five</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one_file.php">Day One</a></li>
        <li><a href="bonus_project_five_day_two_file.php">Day Two</a></li>
         <li><a href="bonus_project_five_day_three_file.php">Day Three</a></li>
         <li><a href="bonus_project_five_day_four_file.php">Day Four</a></li>
         <li><a href="bonus_project_five_day_five_file.php">Day Five</a></li>
         <li><a href="bonus_project_five_day_six_file.php">Day Six</a></li>
         <li><a href="bonus_project_five_day_seven_file.php">Day Seven</a></li>
       
       
      </ul>
    </li>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  <h1>Project II – Design Your Destiny Board</h1>
 
  
 <h1 style="color:#000;">Step 1: </h1>
  <p style="font-size:18px; font-weight:200; padding-left:15px; padding-right:10px;">Go through your magazines and tear the images from them. No gluing yet! Just let yourself have lots of fun looking through magazines and pulling out pictures or words or headlines that strike your fancy. Have fun with it. Make a big pile of images and phrases and words.</p><br><br>
  <form class="" role="form" action="" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:47%; padding-top:10px; padding-bottom:10px; margin-left:300px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details" disabled><?php echo $details;?></textarea>
 <label style="margin-left:160px;">Uploaded Images : <span class="require"></span></label>
 <div style="margin-left:10px; padding-right:100px; width:95%;">
 <a href="<?php echo $url; ?>"><image src="<?php echo $url; ?>" class="images" /></a></div>
     <br><br>
              </form>
  
</div>

 
      
      
      <div class="container-fluid">
 
  <div class="row-fluid" style="margin-top:50px;">
   <p style="color:#000; font-size:28px;">Step 2: </p><br>
  <p style="font-size:18px; font-weight:200; padding-right:10px;">Go through the images and begin to lay your favorites on the board. Eliminate any images that no longer feel right. This step is where your intuition comes in. As you lay the pictures on the board, you’ll get a sense how the board should be laid out. For instance, you might assign a theme to each corner of the board. Health, Job, Spirituality, Relationships, for instance. Or it may just be that the images want to go all over the place. Or you might want to fold the board into a book that tells a story. At my retreats, I’ve seen women come up with wildly creative ways to present a destiny board.</p><br>
   <?php 

  		$query_3="SELECT * FROM project_two_step_two";
  		$query_3_run=mysql_query($query_3);
  		if ($query_3_run) {
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$dbRow['url'] = $dbRow['upload']."/".$dbRow['image_name'];
  					?>
  <form class="" role="form" action="project_two_step_two_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:49%; padding-top:10px; padding-bottom:10px; margin-left:280px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details" disabled><?php echo $dbRow['details']; ?></textarea>
 <label style="margin-left:160px;">Uploaded Images : <span class="require">*</span></label>
  <div style="margin-left:10px; padding-right:100px; width:95%;">
 <a href="<?php echo $dbRow['url']; ?>"><image src="<?php echo $dbRow['url']; ?>" class="images" /></a></div>
     <br><br>
              </form>
              <?php
  				}
  			}
  		}
  	 ?></div>
     
       <div class="container-fluid">
 
  <div class="row-fluid" style="margin-top:50px;">
   <div style="margin-left:-20px;">
   <p style="color:#000; font-size:28px; margin-right:300px;">Step 3: </p><br>
  <p style="font-size:18px; font-weight:200; padding-right:10px;">Glue everything onto the board. Add writing if you want. You can paint on it, or write words with markers.</p></div><br>
   <?php 

  		$query_3="SELECT * FROM project_two_step_three";
  		$query_3_run=mysql_query($query_3);
  		if ($query_3_run) {
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$dbRow['url'] = $dbRow['upload']."/".$dbRow['image_name'];
  					?>
  <form class="" role="form" action="project_two_step_three_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:51%; padding-top:10px; padding-bottom:10px ;margin-left:260px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details" disabled><?php echo $dbRow['details']; ?></textarea>
<label style="margin-left:160px;">Uploaded Images : <span class="require">*</span></label>
  <div style="margin-left:10px; padding-right:100px; width:95%;">
 <a href="<?php echo $dbRow['url']; ?>"><image src="<?php echo $dbRow['url']; ?>" class="images" /></a></div>
     <br><br>

              </form></div>
                      <?php
  				}
  			}
  		}
  	 ?>
       <div class="container-fluid">
 
  <div class="row-fluid" style="margin-top:50px;">
  <div style="margin-left:-40px;">
   <p style="color:#000; font-size:28px;">Step 4: </p><br>
  <p style="font-size:18px; font-weight:200; padding-right:10px;">(optional, but powerful) Leave space in the very center of the destiny board for a fantastic photo of yourself where you look radiant and happy. Paste yourself in the center of your board.</p></div><br>
  <?php 

  		$query_3="SELECT * FROM project_two_step_four";
  		$query_3_run=mysql_query($query_3);
  		if ($query_3_run) {
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$dbRow['url'] = $dbRow['upload']."/".$dbRow['image_name'];
  					?>
   <form class="" role="form" action="project_two_step_four_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:53%; padding-top:10px; padding-bottom:10px; margin-left:240px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details" disabled><?php echo $dbRow['details']; ?></textarea>
<label style="margin-left:160px;">Uploaded Images : <span class="require">*</span></label>
  <div style="margin-left:10px; padding-right:100px; width:95%;">
 <a href="<?php echo $dbRow['url']; ?>"><image src="<?php echo $dbRow['url']; ?>" class="images" /></a></div>
     <br><br>

              </form>
       </div>                     <?php
  				}
  			}
  		}
  	 ?>
       <div class="container-fluid">
 
  <div class="row-fluid" style="margin-top:50px;">
  <div style="margin-left:-60px;">
  <p style="color:#000; font-size:28px;">Step 5: </p><br>
<p style="font-size:18px; font-weight:200; padding-right:10px;">Hang your destiny board in a place where you will see it often</p>
      </div><br> 
       <?php 

  		$query_3="SELECT * FROM project_two_step_five";
  		$query_3_run=mysql_query($query_3);
  		if ($query_3_run) {
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$dbRow['url'] = $dbRow['upload']."/".$dbRow['image_name'];
  					?>
                    <form class="" role="form" action="project_two_step_five_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:55%; padding-top:10px; padding-bottom:10px; margin-left:220px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details" disabled><?php echo $dbRow['details']; ?></textarea>
<label style="margin-left:160px;">Uploaded Images : <span class="require">*</span></label>
  <div style="margin-left:10px; padding-right:100px; width:95%;">
 <a href="<?php echo $dbRow['url']; ?>"><image src="<?php echo $dbRow['url']; ?>" class="images" /></a></div>

              </form></div> <?php
  				}
  			}
  		}
  	 ?>
      
      <strong></strong>
  
     
   
      
        </div>
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
