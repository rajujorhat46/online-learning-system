<!DOCTYPE html>
<html lang="en"> <!--<![endif]-->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<!-- Global Site Tag (gtag.js) - Google Analytics -->

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">  
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.Mask {
  width: 60%;
  
}
@media screen and (max-width: 1400px) {
.Mask {
  width: 60%;  
}

}
@media screen and (max-width: 800px) {
.Mask {
  width: 80%; 
}
 
}
@media screen and (max-width: 600px) {
.Mask{
  width: 100%;  
}
 
}


</style>
</head>
<body> 

<?php 
include_once "connection.php";
$servername = "localhost:3306";
$username = "raju";
$password = "12345";
$dbname = "rohinimundra";


if(isset($_GET['s_no']) && is_numeric($_GET['s_no']))
{
	$s_no = $_GET['s_no'];
}
else
	header('Location: file_search.php');
/*ini_set ("SMTP","ssl://smtp.gmail.com");
ini_set ("sendmail_from","mallikarjuna.tech@gmail.com");*/

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	

        	  
		$result=mysql_query("select * from form where s_no = '$s_no'");
		$count=mysql_num_rows($result);
		
		$baseUrl = "https://www.rohinimundra.com/customer_dashboard";
		
		if( $count>0)
		{
			while($row=mysql_fetch_array($result))
			{  
  
				$to      = $row['login']; // Send email to our user
				$subject = 'Online Learning System Login Details'; // Give the email a subject 
				$message = '';
				$message .= 'Hey<br><br>';
				$message .= 'I am sure you are geared up to move ahead on "The XtraOrdinary You" journey.<br><br>';
				$message .= 'Here are the login details for your Online Learning System.<br><br>';
				$message .= 'Link : ';
				
				$message .= '<a href="'.$baseUrl.'/customer_login.php"> TXY Online Learning System </a><br><br>';
				 
				$message .= 'Username:  '.$row['login'].'<br><br>';
				$message .= 'You can change your password after logging in. Be sure to save your credentials in a safe place for easy access!<br><br>';
				$message .= 'If you have trouble logging in, please send us a message at beawesome@rohinimundra.com, and we will look into it.<br><br>';
				$message .= 'Lets get busy Growing<br>';
				$message .= 'Team Rohini Mundra<br>';
				
				
				// $headers = 'From:beawesome@rohinimundra.com' . "\r\n"; // Set from headers
				$headers  = 'From: beawesome@rohinimundra.com' . "\r\n" .
				'MIME-Version: 1.0' . "\r\n" .
				'Content-type: text/html; charset=utf-8';
				
				$mailSent = mail($to, $subject, $message, $headers); // Send our email
				if($mailSent)
				
					echo "Email sent";
				else
					echo "Email sending failed";
				
			}//while loop
		}//count check
		else
		{
			header('Location: file_search.php');
		}

	}
	catch(PDOException $e){
    echo $e->getMessage();
} 
$conn = null;
?>
</body>

</html>