<?php 
include_once "connection.php";
$servername = "localhost:3306";
$username = "raju";
$password = "12345";
$dbname = "rohinimundra";

if(isset($_GET['s_no']) && is_numeric($_GET['s_no']))
{
	$s_no = $_GET['s_no'];
}
else
	header('Location: file_search.php');
/*ini_set ("SMTP","ssl://smtp.gmail.com");
ini_set ("sendmail_from","mallikarjuna.tech@gmail.com");*/

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	

        	  
		$result=mysql_query("select * from form where s_no = '$s_no'");
		$count=mysql_num_rows($result);
		
		$baseUrl = "https://www.rohinimundra.com/customer_dashboard";
		
		if( $count>0)
		{
			while($row=mysql_fetch_array($result))
			{  
  
				$to      = $row['login']; // Send email to our user
				$subject = 'Welcome to The XtraOrdinary You Journey'; // Give the email a subject 
			        $message = '
Hi '.$row['name'].',

Congratulations on taking the first step in taking charge of your life!

Often, the 1st Step that is the most difficult, yet it is this one step that often changes or lives in ways that we cannot even imagine.

So here we go, lets move ahead in the journey of finding ourselves so that the path is carved for us to get all that we desire.

Please click on the link below and lets explore your dreams and desires in depth.

https://goo.gl/forms/NgZNWWkPUoLyvOVX2

Once you fill this in, share the same with us so we can gear up for the next step.

Get ready to unleash your potential.

Thanks
Team Rohini Mundra';
                                     
				
				  $headers = 'From:beawesome@rohinimundra.com' . "\r\n"; // Set from headers
                                  $mailSent = mail($to, $subject, $message, $headers); // Send our email
				if($mailSent)
					header('Location: file_search.php');
				else
					echo "Email sending failed";
				
			}//while loop
		}//count check
		else
		{
			header('Location: file_search.php');
		}

	}
	catch(PDOException $e){
  echo $result. "<br>" . $e->getMessage();
} 
$conn = null;
?>

