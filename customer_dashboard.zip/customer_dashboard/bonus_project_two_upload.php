<?php 
session_start();
$username=$_SESSION['login'];
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not CUSTOMER. <a href='https://www.rohinimundra.com/customer_dashboard/customer_login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="datatable/jquery.dataTables.min.css">

<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
<script>
        function enableButton2() {
            document.getElementById("button2").disabled = false;
        }
    </script>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header">
<img src="img/TXY logo.png" style="width:220px; height:80px;"> 
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
   <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
      
       <?php
			  include_once "connection.php";
			  
			$result=mysql_query("select * from customer_form where login='$username'");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
         <li><a href="customer_form_view.php?s_no='. $row['s_no'] . '"><i class="icon-user"></i> My Profile</a></li>
        <?php
				  }
			  }
	      
		  ?>
       
        
        <li class="divider"></li>
        <li><a href="customer_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
   
    <li class="" style="margin-left:800px; margin-top:1px;"><a title="" href="customer_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></l
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
 
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="customer.php" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
   <?php 
      $query_3="SELECT
(SELECT count(*) FROM project_one WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') AS p1,
(SELECT count(*) FROM project_two_step_five WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p2,
(SELECT count(*) FROM project_three WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p3,
(SELECT count(*) FROM bonus_project_one_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p4,
(SELECT count(*) FROM bonus_project_two_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p5,
(SELECT count(*) FROM bonus_project_three_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p6,
(SELECT count(*) FROM bonus_project_four_day_seven WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p7";
  		$query_3_run=mysql_query($query_3);
		//var_dump($query_3_run);
  		if ($query_3_run) {
			
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$p1 = $dbRow['p1'];
					$p2 = $dbRow['p2'];
					$p3 = $dbRow['p3'];
					$p4 = $dbRow['p4'];
					$p5 = $dbRow['p5'];
					$p6 = $dbRow['p6'];
					$p7 = $dbRow['p7'];
  					?>
    <li class="active" data-step="1" data-intro="Dashboard details, below you can find your assignment and also some files."><a href="customer.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>TXY-Library</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="ebook.php"  >Ebook PDF File</a></li>
     </ul>
    </li>
        <?php 
      $query_5="SELECT * FROM project_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li class="submenu" style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>My Progress</span> <span class="label label-important"></span></a>
      <ul>
      
        <li><a href="progress_chart.php">My Progress</a></li>
       
      </ul>
    </li>
            <?php 
 }
  }
   }
 ?>  
   
        <li class="submenu" > <a href=""><i class="icon icon-th-list"></i> <span>Label Zone One</span> <span class="label label-important"></span></a>
               
      <ul>
       <li><a href="project_one.php">Label Zone One</a></li>
         

         <?php 
      $query_5="SELECT * FROM project_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_file.php">Label Zone One File</a></li>
        <?php 
 }
  }
   }
 ?>
</ul>
    </li>
      <li class="submenu" style="display:<?php if($p1=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Label Zone Two</span> <span class="label label-important"></span></a>
      <ul>
      
        <li><a href="project_two.php">Label Zone Two</a></li>
       
      </ul>
    </li>
     <li class="submenu" style="display:<?php if($p2=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Label Zone Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three.php">Label Zone Three</a></li>
         <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_three_file.php">Project Three File</a></li>
                                  <?php 
 }
  }
   }
 ?>
         
       </ul>
    </li>
    
      <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Silver Project</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Silver Project</a></li>
  
        <li><a href="bonus_project_one_upload.php">Silver Project One Upload</a></li>
       </ul>
    </li>
      <li class="submenu" style="display:<?php if($p4=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Gold Project</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_two.php">Gold Project</a></li>
         <li><a href="bonus_project_two_upload.php">Gold Project Upload</a></li>
       </ul>
    </li>
      <li class="submenu" style="display:<?php if($p5=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Platinum Project</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_three.php">Platinum Project</a></li>
        <li><a href="bonus_project_three_upload.php">Platinum Project Upload</a></li>
       </ul>
    </li>
  
    
    
      <li class="submenu" style="display:<?php if($p6=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Ruby Project</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one.php">Day One</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_one_file.php">Day One File</a></li>
                                         <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_four_day_two.php">Day Two</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_two_file.php">Day Two File</a></li>
                                                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_three_file.php">Day Three File</a></li>
                                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_four_file.php">Day Four File</a></li>
          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_five.php">Day Five</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_five_file.php">Day Five File</a></li>
               <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_six.php">Day Six</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_six_file.php">Day Six File</a></li>
                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_seven.php">Day Seven</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_seven where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_seven_file.php">Day Seven File</a></li>
                        <?php 
 }
  }
   }
 ?>
       
      </ul>
    </li>
     <li class="submenu" style="display:<?php if($p7=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Diamond Project</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one.php">Day One</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_one_file.php">Day One File</a></li>
                                <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_five_day_two.php">Day Two</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_two_file.php">Day Two File</a></li>
                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_three_file.php">Day Three File</a></li>
                                                    <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_four_file.php">Day Four File</a></li>
                                                             <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_five.php">Day Five</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_five_file.php">Day Five File</a></li>
                                                                       <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_six.php">Day Six</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_six_file.php">Day Six File</a></li>
         <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_seven.php">Day Seven</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
           <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_seven_file.php">Day Seven File</a></li>
                   <?php 
 }
  }
   }
 ?>
       
       
      </ul>
    </li>
  
   <?php
  				}
  			}
  		}
  	 ?>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> </a></div>
  <h1 style="margin-left:50px;">BONUS Project I– Business Plan</h1>
</div>
<div class="container-fluid">

<form class="form-horizontal" role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">

    <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
         
        </div> 
        
        <div class="widget-content nopadding">
          <div class="control-group">
            <h1 align="center" style="font-size:24px;">Upload Word File :</h1>
            
              <label class="control-label">Details : <span class="require">*</span></label>
              <div class="controls">
                 <input name="details" id="details" class="form-control"  required /> 

              </div>
            </div>
            <div class="control-group">
            
              <label class="control-label">File : <span class="require">*</span></label>
              <div class="controls">
                 <input type="file" name="picture" class="form-control" placeholder="File" required /> 
<input type="hidden" class="span11" id="day" name="day" value="<?php echo date("Y-m-d") ?>" required>
              </div>
            </div>
            <div align="center">
             <button type="submit" class="btn btn-default submit" value="Upload news" name="submit" id="submit" style="background-color:#28B779; border-radius:5; width:20%; color:#FFF; padding-top:5px; padding-bottom:5px;">Upload</button>
           
            </div>
           
           
            
             </div></div></div>
    </form>
    
    <?php
	
?>
<?php
?>
   <?php
include("connection.php");
if(isset($_POST['submit']))
{
	function UploadOne($fname)
{
$uploaddir = '/home/rohinimundra/public_html/admin_dashboard/bonus_project_two_word/';
if (is_uploaded_file($fname['tmp_name']))
{
$filname = basename($fname['name']);
$uploadfile = $uploaddir . basename($fname['name']);
if (move_uploaded_file ($fname['tmp_name'], $uploadfile))
{
	
	
}
else
$res = "Could not move ".$fname['tmp_name']." to ".$uploadfile."<br>";
}
else
$res = "File ".$fname['name']." failed to upload.";

}
	
	if ($_FILES['picture']['name'] != "")	
{
$res = UploadOne($_FILES['picture']);
$filname = $_FILES['picture']['name'];
echo ($res);

}

	
		$dt = time();
		$ip = $_SERVER['REMOTE_ADDR'];
		$timezone = "Asia/Calcutta";
		if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
		$time=date('g:i a');
	

$details=$_POST["details"];
$username=$_SESSION['login'];
$day=$_POST["day"];
$completed=$_POST["completed"];

	{
$qry=mysql_query("insert into  bonus_project_two_customer(login,details,day,image_name,completed) values('$username','$details','$day','$filname','1')");

	}
	
	$qry="<font color='green'>Notice added Successfully</font>";
	 echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Your file has been successfully updated THANK YOU')
        window.location.href='bonus_project_two_upload.php'
        </SCRIPT>");	
	}



?>       

</div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
<script type="text/javascript" src="datatable/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="datatable/dataTables.bootstrap.min.js"></script>

</body>
</html>
