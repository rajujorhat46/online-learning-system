<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];
$duplicate_find="SELECT * from project_one_month_two where login='$username'";
$run_duplicate_find=mysql_query($duplicate_find);
if ($run_duplicate_find) 
{
	if (mysql_num_rows($run_duplicate_find)>0) 
	   {
		die("File Already Exist.");
	    }
}
else{
	die('Query not Executed.');
}
$qry=mysql_query("insert into project_one_month_two(login, personally_goal_one,personally_action_one,personally_goal_two,personally_action_two,professionally_goal_one,professionally_action_one,professionally_goal_two,professionally_action_two,financially_goal_one,financially_action_one,financially_goal_two,financially_action_two,other_goal_one,other_action_one,other_goal_two,other_action_two,completed)values('$username','$personally_goal_one','$personally_action_one','$personally_goal_two','$personally_action_two','$professionally_goal_one','$professionally_action_one','$professionally_goal_two','$professionally_action_two','$financially_goal_one','$financially_action_one','$financially_goal_two','$financially_action_two','$other_goal_one','$other_action_one','$other_goal_two','$other_action_two','0')")or die(mysql_error());
if($qry)
{
 header('Location: project_one_month_two_file.php');
}
else
{
	print mysql_error();
}


?>
