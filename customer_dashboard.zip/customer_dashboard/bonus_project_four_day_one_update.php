<?php
include("connection.php");
extract($_POST);

$qry=mysql_query("update bonus_project_four_day_one SET s_no='$s_no',positive_one='$positive_one',impact_one='$impact_one',positive_two='$positive_two',impact_two='$impact_two', positive_three='$positive_three',impact_three='$impact_three',positive_four='$positive_four',impact_four='$impact_four', positive_five='$positive_five',impact_five='$impact_five',completed='1' where s_no='$s_no'")or die(mysql_error());
if($qry)
{
  header('Location: bonus_project_four_day_one_file.php');
}
else
{
	print mysql_error();
}
?>
