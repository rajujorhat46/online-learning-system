 <?php session_start();
?>
 <?php
include("connection.php");
if(isset($_POST['submit_two']))
{
	function UploadOne($fname)
{
$uploaddir = '/home/rohinimundra/public_html/admin_dashboard/project_two_set_three/';
if (is_uploaded_file($fname['tmp_name']))
{
$filname = basename($fname['name']);
$uploadfile = $uploaddir . basename($fname['name']);
if (move_uploaded_file ($fname['tmp_name'], $uploadfile))
{
	
	
}
else
$res = "Could not move ".$fname['tmp_name']." to ".$uploadfile."<br>";
}
else
$res = "File ".$fname['name']." failed to upload.";

}
	
	if ($_FILES['picture']['name'] != "")	
{
$res = UploadOne($_FILES['picture']);
$filname = $_FILES['picture']['name'];
echo ($res);

}

	
		$dt = time();
		$ip = $_SERVER['REMOTE_ADDR'];
		$timezone = "Asia/Calcutta";
		if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
		$time=date('g:i a');
	

$details=$_POST["details"];
$username=$_SESSION['login'];
$duplicate_find="SELECT * from project_two_step_three where login='$username'";
$run_duplicate_find=mysql_query($duplicate_find);
if ($run_duplicate_find) 
{
	if (mysql_num_rows($run_duplicate_find)>0) 
	   {
		die("File Already Exist.");
	    }
}
else{
	die('Query not Executed.');
}

{
$qry=mysql_query("insert into project_two_step_three(login,upload,details,image_name) values('$username','project_two_set_three','$details','$filname')");
if($qry)
{
echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Successfully Inserted')
        window.location.href='project_two.php'
        </SCRIPT>");}
else
{
	print mysql_error();
}

}

	}



?>       