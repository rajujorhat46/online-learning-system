<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not CUSTOMER. <a href='https://www.rohinimundra.com/customer_dashboard/customer_login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Customer Form - Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
</head>
<body>

<!--Header-part-->
<div id="header">
<img src="img/TXY logo.png" style="width:220px; height:80px;"> 
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="customer_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="customer_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
 
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="#"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
  
   
   
    
   

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i></a></div>
  <h1>Please fill up your profile</h1>
  <p style="margin-left:14px; font-size:16px;">*All information shared here will be kept confidential</p>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
  
<form class="form-horizontal" role="form"  method="post" action="customer_form_insert.php" onSubmit="return check();">

    <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
         
        </div> 
        
        <div class="widget-content nopadding">
         
            <div class="control-group">
              <label class="control-label">Age : <span class="require">*</span></label>
              <div class="controls">
                
                  <input type="number" class="span11" id="age" name="age" placeholder="Age" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Marital Status : <span class="require">*</span></label>
              <div class="controls">
                <select class="span11" name="marital" id="marital">
           <option></option>
          <option value="Single">Single</option>
          <option value="Married">Married</option>
          <option value="Divorced">Divorced</option>
           </select>
                
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Birth Place : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="text" class="span11" id="birth_place" name="birth_place" placeholder="Enter Birth Place" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Family Background : <span class="require">*</span></label>
              <div class="controls">
               
                <input type="text" class="span11" id="family_background" name="family_background" placeholder="Family Background" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Which cities have you resided in : <span class="require"></span></label>
              <div class="controls" style="margin-top:8px;">
               
                 <input type="text" class="span11" id="cities" name="cities" placeholder="Location" required>
              </div>
            </div>
            
             <div class="control-group">
              <label class="control-label">What has been your biggest achievement in your life? <span class="require">*</span></label>
              <div class="controls"  style="margin-top:8px;">
                <input type="text" class="span11" id="achievement" name="achievement" placeholder="Your biggest achievement" required>
              </div>
            </div>
             </div></div></div>
     
     <div class="span6">
     <div class="widget-box">
     <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          
        </div>
        <div class="widget-content nopadding">
 <div class="control-group">
              <label class="control-label">Profession : <span class="require">*</span></label>
              <div class="controls">
                <input type="text" class="span11" id="profession" name="profession" placeholder="Profession" required>
              </div>
            </div>
        <div class="control-group">
              <label class="control-label">What do you think is the purpose of your life?<span class="require"></span></label>
              <div class="controls"  style="margin-top:8px;">
                
                 <input type="text" class="span11" id="purpose" name="purpose" placeholder="Purpose of Your Life" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">One goal you want to set for youself in the next 6 months  <span class="require"></span></label>
              <div class="controls" style="margin-top:8px;" >
               <input type="text" class="span11" id="goal" name="goal" placeholder="Goal of Your Life" required>
               
              </div>
            </div>
            <div class="control-group">
              <label class="control-label"> &nbsp;Awards/degrees/recognitions achieved </label>
              <div class="controls" style="margin-top:8px;">
                 <input type="text" class="span11" id="awards" name="awards" placeholder="Awards achieved ">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Your biggest challenge in life?</label>
              <div class="controls" style="margin-top:8px;">
                 <input type="text" class="span11" id="challenge" name="challenge" placeholder="Your biggest challenge">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label"> &nbsp;What do you want to change the most about your current life?

</label>
              <div class="controls" style="margin-top:8px;">
                <input type="text" class="span11" id="current_life" name="current_life" placeholder="About your current life">
              </div>
            </div>
            
           
         
           
         
          
        </div>
      </div>
     
              <button type="submit" class="btn btn-success">Save</button>
           
      </form>
  
           
   
      
        </div>
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
