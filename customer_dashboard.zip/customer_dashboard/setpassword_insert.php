<?php
include("connection.php");
extract($_POST);

if($_POST['password']!==$_POST['confirm_password']) {

echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Password is not matched')
        window.location.href='https://www.rohinimundra.com/customer_dashboard/set_password.php'   
        </SCRIPT>");

} else {

$email=$_POST['email'];
$password=md5($_POST['password']);

$query=mysql_query("insert into customersetpassword(email,password,confirm_password) values('$email','$password','$confirm_password')");

if($query)
{
	 header('Location: customer_login.php');
	 }
else
{
echo "<script>alert('Not register something went worng');</script>";
}}

?>
