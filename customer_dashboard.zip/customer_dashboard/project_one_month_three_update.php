<?php
session_start();
$username=$_SESSION['login'];
include("connection.php");
extract($_POST);

$qry=mysql_query("update project_one_month_three SET id='$id',personally_goal_one='$personally_goal_one',personally_action_one='$personally_action_one', personally_goal_two='$personally_goal_two',personally_action_two='$personally_action_two',professionally_goal_one='$professionally_goal_one',professionally_action_one='$professionally_action_one',professionally_goal_two='$professionally_goal_two',professionally_action_two='$professionally_action_two',financially_goal_one='$financially_goal_one',financially_action_one='$financially_action_one',financially_goal_two='$financially_goal_two',financially_action_two='$financially_action_two',other_goal_one='$other_goal_one',other_action_one='$other_action_one',other_goal_two='$other_goal_two',other_action_two='$other_action_two',completed='1' where id='$id'")or die(mysql_error());
if($qry)
{
//to calculate  the marks
//get the reference data
$q=mysql_query("SELECT * FROM reference where table_name='projectone'");
$referenceData = mysql_fetch_assoc($q, MYSQL_ASSOC);

//check if marks data already exist
$mQuery=mysql_query("SELECT * FROM marks where login='$username' and table_name='projectone'");
if(!mysql_fetch_array($mQuery)){
  //insert the marks according to reference
  $business = $referenceData['business'];
  $pLife = $referenceData['professional_life'];
  $selfValue = $referenceData['self_value'];
  $relationships = $referenceData['relationships'];
  $total = ($business + $pLife + $selfValue + $relationships) * 5;
  mysql_query("insert into marks(login, table_name, business, professional_life, self_value, relationships, total) VALUES ('$username', 'projectone', '$business', '$pLife', '$selfValue', '$relationships', '$total')")or die(mysql_error());
}

  header('Location: project_one_marks.php');
}
else
{
	print mysql_error();
}
?>