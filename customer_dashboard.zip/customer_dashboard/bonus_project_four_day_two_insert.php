<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];

$qry=mysql_query("insert into bonus_project_four_day_two (login, positive_one, impact_one, positive_two, impact_two, positive_three, impact_three, positive_four, impact_four, positive_five, impact_five, completed) values('$username','$positive_one', '$impact_one', '$positive_two', '$impact_two', '$positive_three', '$impact_three', '$positive_four', '$impact_four', '$positive_five', '$impact_five', '0')")or die(mysql_error());
if($qry)
{
 header('Location: bonus_project_four_day_two_file.php');
}
else
{
	print mysql_error();
}


?>
