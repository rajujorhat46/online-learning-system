<?php session_start();
?>
<?php

include("connection.php");
extract($_POST);
$username=$_SESSION['login'];
$qry=mysql_query("insert into customer_form (login,age,marital,birth_place,family_background,cities,achievement,profession,purpose,goal,awards,challenge,current_life) values('$username','$age','$marital','$birth_place','$family_background','$cities','$achievement','$profession','$purpose','$goal','$awards','$challenge','$current_life')")or die(mysql_error());
if($qry)
{
 header('Location: customer.php');
}
else
{
	print mysql_error();
}


?>
