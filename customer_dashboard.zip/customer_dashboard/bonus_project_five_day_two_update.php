<?php
include("connection.php");
extract($_POST);

$qry=mysql_query("update bonus_project_five_day_two SET s_no='$s_no',situation='$situation',cause='$cause',elp_changed='$elp_changed',outcomes='$outcomes',completed='1' where s_no='$s_no'")or die(mysql_error());
if($qry)
{
  header('Location: bonus_project_five_day_two_file.php');
}
else
{
	print mysql_error();
}
?>