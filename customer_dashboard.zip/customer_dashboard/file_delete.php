<?php
include("connection.php");
if(isset($_GET['s_no']))
{
	$s_no=$_GET['s_no'];
	$qry=mysql_query("delete from form_fillup where s_no='$s_no'");
	
	
	if($qry)
	{
			echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Successfully Deleted')
        window.location.href='file_search.php'
        </SCRIPT>");
		
	}
	else
	{
		print mysql_error();
		echo '<br> incorrect serial no! <br><br>';
		echo '<a href="file_search.php">Click here to go Back!</a>';
	}
}else
{
	echo '<br> 404 ERROR ! Page Not found. <br><br>';
	echo '<a href="file_search.php">Click here to go Back!</a>';
}
?>