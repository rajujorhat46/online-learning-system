<?php
    include_once "connection.php";
    if(isset($_GET['login']))
	{
		$login=$_GET['login'];
			  
			  $result=mysql_query("select * from form where login='$login'",$con);
			  $count=mysql_num_rows($result);
			  
			  if($count>0)
			  {
				  while($row=mysql_fetch_assoc($result))
				  {
			  $id=$row['id'];
			  $email=$row['email'];
			 
		
				  }
			  }else
			  {
			  	echo 'Wrong Input. try again later!! . :( <br><br>';
				echo '<a href="file_search.php">Click here to go Back!</a>';
				
			  }
	}else
	{
		
		
	}
?>
 <?php

extract($_POST);
if($_SERVER['REQUEST_METHOD'] == 'POST'){
if($_POST['password']!==$_POST['confirm_password']) 
{
     $_SESSION['error1']="Confirm Password is not matched";     
} 

else 
{

    $email=$_POST['email'];
    $password=md5($_POST['password']);
    $confirm_password=$_POST['confirm_password'];
    $duplicate_find="SELECT * from customersetpassword where email='$email'";
    $run_duplicate_find=mysql_query($duplicate_find);
    if ($run_duplicate_find) 
{
	if (mysql_num_rows($run_duplicate_find)>0) 
	   {
		//die("File Already Exist.");
		$_SESSION['error1']="File Already Exist"; 
	    }else{
	    $query1=mysql_query("insert into customersetpassword(email,password,confirm_password,terms) values('$email','$password','$confirm_password','0')");
    if($query1)
    
     {
     print"<script>window.location ='customer_login.php';</script>";
       header('Location: customer_login.php');
       exit("exit here.");
     }
    else
     {
	print mysql_error();
     }
	    }
}
else{
	die('Query not Executed.');
}
    

}
}

?> 
<!DOCTYPE html>
<html lang="en">
    
<head>
        <title>Admin</title><meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="css/matrix-login.css" />
        <link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

    </head>
    <body>
                   
          <div id="loginbox" style="margin-top:-130px;">
            <form id="loginform" class="form-vertical" role="form" method="post" action="">
           
             <div class="control-group normal_text"> <h3><img src="css/TXY logo.png" alt="Login" /></h3></div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
           
                            <span class="add-on bg_lg"><img src="img/client.png"></span><input type="text" placeholder="Email" name="email" value="<?php echo $login; ?>" style="padding-top:10px; padding-bottom:8px;" required />
                        </div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
 <span class="add-on bg_ly"><img src="img/lock.png"></span><input type="password" placeholder="Password" name="password" required style="padding-top:10px; padding-bottom:8px;" />
                        </div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
 <span class="add-on bg_ly"><img src="img/lock.png"></span><input type="password" placeholder="Confirm Password" name="confirm_password" required style="padding-top:10px; padding-bottom:8px;" />
                        </div>
                    </div>
                </div>
                <div class="form-actions">
                    <span style="margin-left:125px;">
                     <button type="submit" class="btn btn-success" name="submit" id="submit">Set Password</button></span>
                </div>
                </form>
         
        </div>


         <p align="center" style="color:#F00; font-size:18px; font-weight:700;"><?php echo $_SESSION['error1']; ?></p>       
            
        
        <script src="js/jquery.min.js"></script>  
        <script src="js/matrix.login.js"></script> 
        
 
    </body>

</html>

