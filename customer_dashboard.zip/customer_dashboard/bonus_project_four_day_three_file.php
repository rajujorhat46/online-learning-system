<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not CUSTOMER. <a href='https://www.rohinimundra.com/customer_dashboard/customer_login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="datatable/jquery.dataTables.min.css">

<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
<script>
        function enableButton2() {
            document.getElementById("button2").disabled = false;
        }
    </script>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header">
<img src="img/TXY logo.png" style="width:220px; height:80px;"> 
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>   <?php
					      $username=$_SESSION['login']  
					     ?>
  <span class="text">Welcome  <?php echo $username;?></span><b class="caret"> </b></a>
       
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="customer_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="customer_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
 
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
   <?php 
      $query_3="SELECT
(SELECT count(*) FROM project_one_month_three WHERE day <= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and completed=1 and login='$username') AS p1,
(SELECT count(*) FROM project_two_step_five WHERE day <= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and completed=1 and login='$username') as p2,
(SELECT count(*) FROM project_three WHERE day <= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and completed=1 and login='$username') as p3,
(SELECT count(*) FROM bonus_project_one_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and completed=1 and login='$username') as p4,
(SELECT count(*) FROM bonus_project_two_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and completed=1 and login='$username') as p5,
(SELECT count(*) FROM bonus_project_three_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and completed=1 and login='$username') as p6,
(SELECT count(*) FROM bonus_project_four_day_seven WHERE day <= DATE_SUB(CURDATE(), INTERVAL 7 DAY) and completed=1 and login='$username') as p7";
  		$query_3_run=mysql_query($query_3);
		//var_dump($query_3_run);
  		if ($query_3_run) {
			
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$p1 = $dbRow['p1'];
					$p2 = $dbRow['p2'];
					$p3 = $dbRow['p3'];
					$p4 = $dbRow['p4'];
					$p5 = $dbRow['p5'];
					$p6 = $dbRow['p6'];
					$p7 = $dbRow['p7'];
  					?>
    <li class="active" data-step="1" data-intro="Dashboard details, below you can find your assignment and also some files."><a href="customer.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>File</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="ebook.php"  >Ebook PDF File</a></li>
     </ul>
    </li>
   
        <li class="submenu" > <a href=""><i class="icon icon-th-list"></i> <span>Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_one_month_one.php">One Month Level</a></li>
         <?php 
      $query_5="SELECT * FROM project_one_month_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_month_one_file.php">One Month Level File</a></li>
        <?php 
 }
  }
   }
 ?>

        <li><a href="project_one_month_two.php">Two Month Level</a></li>
         <?php 
      $query_5="SELECT * FROM project_one_month_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_month_two_file.php">Two Month Level File</a></li>
        
                <?php 
 }
  }
   }
 ?>
        
        
        <li><a href="project_one_month_three.php">Three Month Level</a></li>
        <?php 
      $query_5="SELECT * FROM project_one_month_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_month_three_file.php">Three Month Level File</a></li>
                         <?php 
 }
  }
   }
 ?>
     </ul>
    </li>
      <li class="submenu" style="display:<?php if($p1=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Project Two</span> <span class="label label-important"></span></a>
      <ul>
      
        <li><a href="project_two.php">Project Two</a></li>
       
      </ul>
    </li>
     <li class="submenu" style="display:<?php if($p2=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three.php">Project Three</a></li>
         <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_three_file.php">Project Three File</a></li>
                                  <?php 
 }
  }
   }
 ?>
         
       </ul>
    </li>
    
      <li class="submenu" style="display:<?php if($p3=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
  
        <li><a href="bonus_project_one_upload.php">Bonus Project One Upload</a></li>
       </ul>
    </li>
      <li class="submenu" style="display:<?php if($p4=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
         <li><a href="bonus_project_two_upload.php">Bonus Project Two Upload</a></li>
       </ul>
    </li>
      <li class="submenu" style="display:<?php if($p5=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
        <li><a href="bonus_project_three_upload.php">Bonus Project Three Upload</a></li>
       </ul>
    </li>
    
    
    
      <li class="submenu" style="display:<?php if($p6=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Four</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one.php">Day One</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_one_file.php">Day One File</a></li>
                                         <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_four_day_two.php">Day Two</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_two_file.php">Day Two File</a></li>
                                                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_three_file.php">Day Three File</a></li>
                                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_four_file.php">Day Four File</a></li>
          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_five.php">Day Five</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_five_file.php">Day Five File</a></li>
               <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_six.php">Day Six</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_six_file.php">Day Six File</a></li>
                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_seven.php">Day Seven</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_seven where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_seven_file.php">Day Seven File</a></li>
                        <?php 
 }
  }
   }
 ?>
       
      </ul>
    </li>
     <li class="submenu" style="display:<?php if($p7=='0'){ echo 'none'; } else{ echo ''; } ?>;"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Five</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one.php">Day One</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_one_file.php">Day One File</a></li>
                                <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_five_day_two.php">Day Two</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_two_file.php">Day Two File</a></li>
                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_three_file.php">Day Three File</a></li>
                                                    <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_four_file.php">Day Four File</a></li>
                                                             <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_five.php">Day Five</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_five_file.php">Day Five File</a></li>
                                                                       <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_six.php">Day Six</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_six_file.php">Day Six File</a></li>
         <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_seven.php">Day Seven</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
           <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_seven_file.php">Day Seven File</a></li>
                   <?php 
 }
  }
   }
 ?>
       
       
      </ul>
    </li>
  
   <?php
  				}
  			}
  		}
  	 ?>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i></a></div>
  <h1>Bonus Project Four – Increase the Circle of Your Influence</h1>
</div>
<div class="container-fluid">
<table border="1" class="table" id="order_details" style="margin-left:10px; margin-top:30px;">
<thead>
<tr>
<th style="background-color:#FFF;"><p style="font-size:16px;  margin-top:5px;">S.No.</p></th>
<th scope="col" style="background-color:#FFF;"><p style="font-size:16px;  margin-top:5px;">Positive Statement</a></th>
<th scope="col" style="background-color:#FFF;"><p style="font-size:16px;  margin-top:5px;">Impact</p></th>
<th scope="col" style="background-color:#FFF;"><p style="font-size:16px;  margin-top:5px;">Action</p></th>
</tr>
</thead>
<tbody>
 <?php
			  include_once "connection.php";
			  
			$result=mysql_query("select * from bonus_project_four_day_three where  login='$username'");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  $i=0;
				  $sl=0;
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
<tr>
<td align="center"><p align="center" style="font-size:14px; color:#000;"><?php echo ++$sl; ?></p></td>
<td><p align="center" style="font-size:14px; color:#000;"><?php echo $row["positive_one"];  ?></p></td>
<td> <p align="center" style="font-size:14px; color:#000;"><?php echo $row["impact_one"];  ?></p></td>
<?php 
echo' <td align="center"><p align="center" style="font-size:14px; color:#000;"><a href="bonus_project_four_day_three_view.php? s_no='. $row['s_no'] . '">
<button type="button" style="background-color:#51A251; border-color:#51A251; color:#fff;" >View</button> </a></p>';
		
		 ?>


         </td>
                <?php
				  }
			  }
	      
		  ?>

</tr>


</tbody>
</table></div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
<script type="text/javascript" src="datatable/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="datatable/dataTables.bootstrap.min.js"></script>

</body>
</html>
