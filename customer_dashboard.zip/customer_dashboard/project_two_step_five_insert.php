<?php 
session_start();
?>
 <?php
include("connection.php");
if(isset($_POST['submit_four']))
{
	function UploadOne($fname)
{
$uploaddir = '/home/rohinimundra/public_html/admin_dashboard/project_two_set_five/';
if (is_uploaded_file($fname['tmp_name']))
{
$filname = basename($fname['name']);
$uploadfile = $uploaddir . basename($fname['name']);
if (move_uploaded_file ($fname['tmp_name'], $uploadfile))
{
	
	
}
else
$res = "Could not move ".$fname['tmp_name']." to ".$uploadfile."<br>";
}
else
$res = "File ".$fname['name']." failed to upload.";

}
	
	if ($_FILES['picture']['name'] != "")	
{
$res = UploadOne($_FILES['picture']);
$filname = $_FILES['picture']['name'];
echo ($res);

}

$details=$_POST["details"];
$day=$_POST["day"];
$username=$_SESSION['login'];
$completed=$_POST["completed"];
$duplicate_find="SELECT * from project_two_step_five where login='$username'";
$run_duplicate_find=mysql_query($duplicate_find);
if ($run_duplicate_find) 
{
	if (mysql_num_rows($run_duplicate_find)>0) 
	   {
		die("File Already Exist.");
	    }
}
else{
	die('Query not Executed.');
}
{
$qry=mysql_query("insert into  project_two_step_five(login,upload,details,day,image_name,completed) values('$username','project_two_set_five','$details','$day','$filname','1')");
}
if($qry)
{
//to calculate  the marks
//get the reference data
$q=mysql_query("SELECT * FROM reference where table_name='projecttwo'");
$referenceData = mysql_fetch_assoc($q, MYSQL_ASSOC);

$total1 = 0;
$sqlOne = mysql_query("SELECT * FROM marks where login='$username' and table_name='projectone'");

$projectoneData = mysql_fetch_assoc($sqlOne, MYSQL_ASSOC);

  $total1 = $projectoneData['total'];
  
//check if marks data already exist
$mQuery=mysql_query("SELECT * FROM marks where login='$username' and table_name='projecttwo'");
if(!mysql_fetch_array($mQuery)){
  //insert the marks according to reference
  $business = $referenceData['business'];
  $pLife = $referenceData['professional_life'];
  $selfValue = $referenceData['self_value'];
  $relationships = $referenceData['relationships'];
  $total = ($business + $pLife + $selfValue + $relationships) * 5;
  $grand_total= $total1 + $total;
  mysql_query("insert into marks(login, table_name, business, professional_life, self_value, relationships, total, grand_total) VALUES ('$username', 'projecttwo', '$business', '$pLife', '$selfValue', '$relationships', '$total', '$grand_total')")or die(mysql_error());
}

 echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Successfully Inserted')
        window.location.href='project_two_marks.php'
        </SCRIPT>");
}
else
{
	print mysql_error();
}
}



?>       