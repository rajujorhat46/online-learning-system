jQuery Popup
=========

>This is a simple website with a popup written in jQuery. The popup loads on document.ready

(Lincense: MIT) - *[Click here for a preview] [1]*
[1]:http://fleroviums.github.io/popup

