<?php
include("connection.php");
extract($_POST);



$qry=mysql_query("update project_one_month_two SET id='$id',personally_goal_one='$personally_goal_one',personally_action_one='$personally_action_one', personally_goal_two='$personally_goal_two',personally_action_two='$personally_action_two',professionally_goal_one='$professionally_goal_one',professionally_action_one='$professionally_action_one',professionally_goal_two='$professionally_goal_two',professionally_action_two='$professionally_action_two',financially_goal_one='$financially_goal_one',financially_action_one='$financially_action_one',financially_goal_two='$financially_goal_two',financially_action_two='$financially_action_two',other_goal_one='$other_goal_one',other_action_one='$other_action_one',other_goal_two='$other_goal_two',other_action_two='$other_action_two',completed='1' where id='$id'")or die(mysql_error());
if($qry)
{
  header('Location: project_one_month_two_file.php');
}
else
{
	print mysql_error();
}
?>
