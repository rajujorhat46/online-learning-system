<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];

$qry=mysql_query("insert into bonus_project_five_day_two (login, situation, cause, elp_changed, outcomes, completed) values('$username','$situation', '$cause', '$elp_changed', '$outcomes', '0')")or die(mysql_error());
if($qry)
{
 header('Location: bonus_project_five_day_two_file.php');
}
else
{
	print mysql_error();
}


?>
