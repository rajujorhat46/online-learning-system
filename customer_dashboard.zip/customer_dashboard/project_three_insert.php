<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];
$duplicate_find="SELECT * from project_three where login='$username'";
$run_duplicate_find=mysql_query($duplicate_find);
if ($run_duplicate_find) 
{
	if (mysql_num_rows($run_duplicate_find)>0) 
	   {
		die("File Already Exist.");
	    }
}
else{
	die('Query not Executed.');
}
$qry=mysql_query("insert into project_three(login, certainity_one,certainity_two,significance_one,significance_two,connection_one,connection_two,contribution_one,contribution_two,variety_one,variety_two,growth_one,growth_two,action_one,relation_one,identity_one,action_two,relation_two,identity_two,action_three,relation_three,identity_three,action_four,relation_four,identity_four,action_five,relation_five,identity_five,
action_six,relation_six,identity_six,day,completed)values('$username','$certainity_one','$certainity_two','$significance_one','$significance_two','$connection_one','$connection_two','$contribution_one','$contribution_two','$variety_one','$variety_two','$growth_one','$growth_two','$action_one','$relation_one','$identity_one','$action_two','$relation_two','$identity_two','$action_three','$relation_three','$identity_three','$action_four','$relation_four','$identity_four','$action_five','$relation_five','$identity_five','$action_six','$relation_six','$identity_six','$day','0')")or die(mysql_error());
if($qry)
{
 header('Location: project_three_file.php');
}
else
{
	print mysql_error();
}


?>
