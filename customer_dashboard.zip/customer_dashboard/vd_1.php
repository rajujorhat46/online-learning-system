<?php 
session_start();
$username=$_SESSION['login'];
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an CUSTOMER. <a href='https://www.rohinimundra.com/customer_dashboard/customer_login.php'>Go to Login Page</a>";
	die();
}

?>

<!DOCTYPE html>
<html lang="en"><head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />

<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />

<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />

<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link href="assetsss/introjs.css" rel="stylesheet">


<script>
function RandomQuoteByInterval($TimeBase, $QuotesArray){
 
    // Make sure it is a integer
    $TimeBase = intval($TimeBase);
 
    // How many items are in the array?
    $ItemCount = count($QuotesArray);
 
    // By using the modulus operator we get a pseudo
    // random index position that is between zero and the
    // maximal value (ItemCount)
    $RandomIndexPos = ($TimeBase % $ItemCount);
 
    // Now return the random array element
    return $QuotesArray[$RandomIndexPos];
}
</script>

<style>
.disable {
    position: relative;
}
.disable:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 100;
}
.disable a {
    color: gray;
    cursor: default;
}

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: black;
    padding: 30px 65px;
    text-align: center;
    border-radius: 10px;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}

.button1 {
    background-color: #019000; 
    color: black; 
    border: 2px solid #019000;
}

.button1:hover {
    background-color: #019000;
    color: white;
}


.button3 {
    background-color: #FA8322; 
    color: black; 
    border: 2px solid #FA8322;
}

.button3:hover {
    background-color: #f44336;
    color: white;
}

 </style>
</head>
<body>

<!--Header-part-->
<div id="header" style="margin-top:10px;">
<img src="img/TXY logo.png" style="width:220px; height:80px;"> 
</div>
<!--close-Header-part--> 


<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
   <li class="" ><a title=""><span class="text" style="color:#fff;"></span></a>
    </li>
 <li  class="dropdown" id="profile-messages" style="margin-left:800px; margin-top:1px;"><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text" style="color:#fff;">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
      
       <?php
			  include_once "connection.php";
			  
			$result=mysql_query("select * from customer_form where login='$username'");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
         <li><a href="customer_form_view.php?s_no='. $row['s_no'] . '"><i class="icon-user"></i> My Profile</a></li>
        <?php
				  }
			  }
	      
		  ?>
       
        
        <li class="divider"></li>
        <li><a href="customer_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  

    
  </ul>
</div>

 
<!--close-top-Header-menu-->
<!--start-top-serch-->
<div id="search">
  </div>
<!--close-top-serch-->         
<div class="maintext">
  
<div class="jquery-script-ads">
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></div>
</div>
<div id="boxes">
  <div style="top: 199.5px; left: 551.5px; display: none;" id="dialog" class="window"> 
    <div id="lorem">
      <p style="font-size:24px; color:#0C6; font-weight:600; line-height:20px;">
      
      
      
      </p>
    </div>
   
  </div>
  <div style="width: 1478px; font-size: 32pt; color:white; height: 602px; display: none; opacity: 0.8;" id="mask"></div>
</div>
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script> 
<script src="main.js"></script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>--></div>     
<div id="sidebar" style="background-color: #2E363F";><a href="customer.php" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul style="background-color: #2E363F";>
   <?php 
      $query_3="SELECT
(SELECT count(*) FROM project_one WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') AS p1,
(SELECT count(*) FROM project_two_step_five WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p2,
(SELECT count(*) FROM project_three WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p3,
(SELECT count(*) FROM bonus_project_one_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p4,
(SELECT count(*) FROM bonus_project_two_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p5,
(SELECT count(*) FROM bonus_project_three_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p6,
(SELECT count(*) FROM bonus_project_four_day_seven WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p7";
  		$query_3_run=mysql_query($query_3);
		//var_dump($query_3_run);
  		if ($query_3_run) {
			
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$p1 = $dbRow['p1'];
					$p2 = $dbRow['p2'];
					$p3 = $dbRow['p3'];
					$p4 = $dbRow['p4'];
					$p5 = $dbRow['p5'];
					$p6 = $dbRow['p6'];
					$p7 = $dbRow['p7'];
  					?>
  
  
  					
    <li class="active" data-step="1" data-intro="Find all elements at a glance"><a href="customer.php"><img src="img/icon/32/home.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Dashboard</span></a> </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;Help<span class="label label-important"></span></a>
      <ul>
        <li><a href="help.php"  >Help</a></li>
     </ul>
    </li>
    
   <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;TXY-Library<span class="label label-important"></span></a>
      <ul>
        <li><a href="eb_1.php"  >TXY Libarary</a></li>
     </ul>
    </li>
       
        <li class="submenu" style="background-color: #2E363F;" > <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>My Progress</span> <span class="label label-important"></span></a>
      <ul>
       <?php 
      $query_5="SELECT * FROM project_one where login='$username' and completed='1'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
      
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="progress_chart.php">My Progress</a></li>
        <?php }
  }
   }
 ?> 
      </ul>
    </li>
            
 
   
        <li class="submenu" style="background-color: #2E363F;" ><a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span> Zone One </span> <span class="label label-important"></span></a>
               
      <ul>
       
       <li><a href="project_one.php">Zone One</a></li>
               
 <?php 
      $query_5="SELECT * FROM project_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?> 
       
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_file.php">Zone One File</a></li>
        <?php 
 }
  }
   }
 ?>
</ul>
    </li>
          <?php 
	if($p1=='0'){
		echo' <li class="submenu" style="background-color: #2E363F;"> <a href="" title="This project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Zone Two</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu" style="background-color: #2E363F;"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp;<span>Zone Two</span> <span class="label label-important"></span></a>';
			}
	?>
      <ul>
        <li style="display:<?php if($p1=='0'){ echo 'none'; } else{ echo ''; } ?>;"><a href="project_two.php">Zone Two</a></li>
       
      </ul>
    </li>
    
     <?php 
	if($p2=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Zone Three</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Zone Three</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
     
    <ul>
        <li><a href="project_three.php">Zone Three</a></li>
         <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_three_file.php">Zone Three File</a></li>
                                  <?php 
 }
  }
   }
 ?>
         
       </ul>
    </li>
    
    
   
   
    <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Zone Four</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Five</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Zone Six</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Seven</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Eight</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Nine</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Zone Ten</span> <span class="label label-important"></span></a>
      
    </li>
    

    
      <li class="submenu" style="background-color: #2E363F;" ><a href="" title="This project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span> Bonus Project One </span> <span class="label label-important"></span></a>
    
      <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
  
        <li><a href="bonus_project_one_upload.php">Bonus Project One Upload</a></li>
       </ul>
                                         <?php 
 }
  }
   }
 ?>
    </li>
    
    
    
    <?php 
	if($p4=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Two</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Two</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
         <li><a href="bonus_project_two_upload.php">Bonus Project Two Upload</a></li>
       </ul>
    </li>
    
    
    
    <?php 
	if($p5=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Three</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Three</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
        <li><a href="bonus_project_three_upload.php">Bonus Project Three Upload</a></li>
       </ul>
    </li>
  
    
    
     <?php 
	if($p6=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Four</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Four</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_four_day_one.php">Day One</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_one_file.php">Day One File</a></li>
                                         <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_four_day_two.php">Day Two</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_two_file.php">Day Two File</a></li>
                                                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_three_file.php">Day Three File</a></li>
                                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_four_file.php">Day Four File</a></li>
          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_five.php">Day Five</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_five_file.php">Day Five File</a></li>
               <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_six.php">Day Six</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_six_file.php">Day Six File</a></li>
                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_seven.php">Day Seven</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_seven where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_seven_file.php">Day Seven File</a></li>
                        <?php 
 }
  }
   }
 ?>
       
      </ul>
    </li>
    
    <?php 
	if($p6=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Five</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Five</span> <span class="label label-important"></span></a>';
			}
	?>
   <ul>
        <li><a href="bonus_project_five_day_one.php">Day One</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_one_file.php">Day One File</a></li>
                                <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_five_day_two.php">Day Two</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_two_file.php">Day Two File</a></li>
                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_three_file.php">Day Three File</a></li>
                                                    <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_four_file.php">Day Four File</a></li>
                                                             <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_five.php">Day Five</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_five_file.php">Day Five File</a></li>
                                                                       <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_six.php">Day Six</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_six_file.php">Day Six File</a></li>
         <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_seven.php">Day Seven</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
           <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_seven_file.php">Day Seven File</a></li>
                   <?php 
 }
  }
   }
 ?>
       
       
      </ul>
    </li>
  
   <?php
  				}
  			}
  		}
  	 ?>

 
</div>
<!--sidebar-menu-->

<!--main-container-part-->
<div id="content" style="padding-bottom:200px;">

<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="customer.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
 

 
<!--End-breadcrumbs-->
<!--Action boxes-->
  <div class="container-fluid" style="margin-top:40px;">
  <p align="center" style="font-size:32px; color:#000; font-weight:600; font-family:'Adobe Fangsong Std R'; font-style:italic;">Click on the video and enter the learning Zone</p>
    <div class="quick-actions_homepage" >
      <ul class="quick-actions" style="margin-left:50px;">
        <li class="bg_lb span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href="video.php"  class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:240px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;">&nbsp;
 Zone One</p> </a> </li>
        
        <li class="bg_lo span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%; "> <a href=""  title="Your project will unlock after 10 days from the date you completed your 1st one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Two</p> </a> </li>
       
      <li class="bg_ls span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 2nd one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Three</p> </a> </li>
       <li class="bg_ly span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 3rd one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Four</p> </a> </li>
        
        <li class="bg_lb span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 4th one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Five</p> </a> </li>
 
 <li class="bg_lo span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 5th one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Six</p> </a> </li>
 
 <li class="bg_ls span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 6th one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Seven</p> </a> </li>
 
 <li class="bg_ly span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 7th one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Eight</p> </a> </li>
 
 <li class="bg_lb span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 8th one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Nine</p> </a> </li>
 
 <li class="bg_lo span2" data-step="2" data-intro="Find all elements at a glance" style="width:30%;"> <a href=""  title="Your project will unlock after 10 days from the date you completed your 9th one" class="tip-bottom"><br><br><img src="img/3312.jpg" style="width:220px; padding-top:5px;"><br><br><span class="label label-important"></span> <p style="font-size:18px; font-weight:600;"><img src="img/padlock.png">&nbsp;
 Zone Ten</p> </a> </li>


      </ul>
      
    </div>
      
   
<!--End-Action boxes-->    

<!--Chart-box-->    
  
<!--End-Chart-box--> 
    <hr/>
   
<!--end-main-container-part-->

<!--Footer-part-->
<div style="margin-top:200px;">
</div>


<script type="text/javascript" src="assetsss/intro.js"></script>
 <script src="jss/jquery-2.1.4.js"></script>
<script src="jss/jquery.mobile.min.js"></script> 
<script src="jss/main.js"></script> <!-- Resource jQuery -->
<script src="js/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/matrix.js"></script> 



</body>
</html>
