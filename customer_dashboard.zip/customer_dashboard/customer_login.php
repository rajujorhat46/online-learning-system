<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_POST['login'])) {
	$email=$_POST['email'];
	$password=md5($_POST['password']);
	$query=mysql_query("SELECT * FROM customersetpassword WHERE email='$email' and password='$password'");
	$num=mysql_fetch_array($query);
	if($num>0) {	
		$extra="customer.php";
		
		$_SESSION['login']=$_POST['email'];
		$_SESSION['id']=$num['id'];
		$_SESSION['username']=$num['email'];
		$uip=$_SERVER['REMOTE_ADDR'];
		$terms = intval($num['terms']);
		$status=1;
		
		$log=mysql_query("insert into customer_userlog(userEmail,status) values('".$_SESSION['login']."','$status')");
		$host=$_SERVER['HTTP_HOST'];
		$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
		
		if ($terms=='1'){ header('Location: customer.php'); } 
		else { header('Location: welcome.php');}
					
		/*$query_3="SELECT * FROM customersetpassword where email='$email'"; 
		$query_3_run=mysql_query($query_3);
		if ($query_3_run) {
			if (mysql_num_rows($query_3_run)>0) {
				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$terms = $dbRow['terms'];
					if ($terms=='1'){ header('Location: customer.php'); } 
					else { header('Location: welcome.html');}
				}
			}
		}*/
	}
	else {
		$extra="customer_login.php";
		$email=$_POST['email'];
		$uip=$_SERVER['REMOTE_ADDR'];
		$_SESSION['error1']="Incorrect Username or Password";
		$status=0;
		$log=mysql_query("insert into customer_userlog(userEmail,userip,status) values('$email','$uip','$status')");
		$host  = $_SERVER['HTTP_HOST'];
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/matrix-login.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
<div id="loginbox">
  <p align="center" style="color:#0C0; font-size:18px; font-weight:700;"><?php echo $_SESSION['error1']; ?></p>

   <form id="loginform" class="form-vertical" role="form" method="post">
             
				 <div class="control-group normal_text"> <h3><img src="css/TXY logo.png" alt="Login" /></h3></div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
                        
                        <div class="input-group-addon">
	<span class="glyphicon glyphicon-envelope"></span> 
                       </div>
                            <span class="add-on bg_lg"><img src="img/client.png"></span><input type="text" placeholder="Email Id" required  name="email" style="padding-top:10px; padding-bottom:8px;"  />
                        </div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
 <span class="add-on bg_ly"><img src="img/lock.png"></span><input type="password" placeholder="Password" name="password" required style="padding-top:10px; padding-bottom:8px;"/ >
                        </div>
                    </div>
                </div>
                <div class="form-actions">
                    <span class="pull-left">
                     <button type="submit" class="btn btn-success" name="login" id="login" style="background-color:#2F96B4; margin-left:20px; width:100px;">Login</button></span>
                   
                     <span class="pull-left" style="margin-left:20px;" ><a href="set_password.php"  class="flip-link btn btn-info" style="background-color:#229D68;">New User</a></span></span>
                  
                    <span class="pull-right">
                     <span class="pull-left"  style="margin-right:5px;"><a href="forgotpassword.php" class="flip-link btn btn-info">Forgot password?</a></span></span>
                </div>
            </form>
         
</div>
<script src="js/jquery.min.js"></script> 
<script src="js/matrix.login.js"></script>
</body>
</html>
