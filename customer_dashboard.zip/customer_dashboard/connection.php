<?php
$con=mysql_connect('localhost:3306','raju','12345');
mysql_select_db('rohinimundra',$con);
?>
