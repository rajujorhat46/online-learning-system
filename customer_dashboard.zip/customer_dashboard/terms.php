<?php
include("connection.php");
session_start();
$username=$_SESSION['login'];
$terms='1';

	
if(isset($_POST['submit'])){
	$qry = mysql_query("update customersetpassword SET terms='1' where email='$username'");
	if($qry){ header('Location: customer.php'); }
	else { print mysql_error(); die(mysql_error()); }
}
	
?> 
<!DOCTYPE html>
<html class="google mmfb" lang="en">
<meta charset="utf-8">
<script>
(function(H){H.className=H.className.replace(/\bgoogle\b/,'google-js')})(document.documentElement)
</script>
<meta content="initial-scale=1, minimum-scale=1, width=device-width" name="viewport">
<title>Online Learning System | Terms And Conditions</title>
<script src="https://www.google.com/js/google.js"></script>
<link href="//fonts.googleapis.com/css?family=RobotoDraft:300,400,500,700,italic|Product+Sans:400&amp;lang=en" rel="stylesheet">
<link href="https://www.google.com/policies/css/default.css" rel="stylesheet">
<div class="maia-header" id="maia-header" role="banner">
<div class="maia-aux">
</div></div>

<div id="maia-main" role="main">

<div class="maia-article" role="article">
<div class="maia-teleport" id="content"></div>
<h1>TERMS AND CONDITIONS</h1>

<h2>1. General</h2>
<p>These Terms and Conditions ("Agreement") governs the use of the services ("Service") that are made available by https://www.rohinimundra.com Solutions Inc. ("https://www.https://www.rohinimundra.com", "we" or "us"). These Terms and Conditions represent the whole agreement and understanding between rohinimundra.com and the individual or entity who subscribes to our service ("Subscriber" or "you").
<p>PLEASE READ THIS AGREEMENT CAREFULLY. By submitting your application and by your use of the Service, you agree to comply with all of the terms and conditions set out in this Agreement. https://www.rohinimundra.com may terminate your account at any time, with or without notice, for conduct that is in breach of this Agreement, for conduct that rohinimundra.com believes is harmful to its business, or for conduct where the use of the Service is harmful to any other party.
<p>https://www.https://www.rohinimundra.com may, in its sole discretion, change or modify this Agreement at any time, with or without notice. Such changes or modifications shall be made effective for all Subscribers upon posting of the modified Agreement to this web address (URL): https://www.https://www.rohinimundra.com. You are responsible to read this document from time to time to ensure that your use of the Service remains in compliance with this Agreement.
<h2 id="toc-services">2. Services</h2>
<p>https://www.rohinimundra.com offers Subscribers domain name registration, website hosting, and email hosting services for the duration of the service term purchased from rohinimundra.com.
<p>Services are provided on the basis of facility and equipment availability. https://www.rohinimundra.com reserves the right to modify, change, or discontinue any aspect of the Services at any time.
<p>Access to the web and email servers is terminated upon expiry of the Service.
<p>Details regarding your account can be found in your account control panel (https://www.rohinimundra.com/customer_dashboard/customer_login.php/).
<h2 id="toc-account">3. Service Fees / Payments / Invoices</h2>
<p>All https://www.rohinimundra.com fees and charges are quoted and billed in Indian Rupees unless otherwise noted.<br>
The exchange rate used ("Exchange Rate") is subject to change from time to time and can always be found on the https://www.rohinimundra.com website at: https://www.rohinimundra.com/terms_conditions.html/exchange_rate/
<p>https://www.rohinimundra.com uses an automated payment processing system and only accepts credit card or NEFT or Payumoney payments at this time. All Subscribers are required to maintain valid payment information on file for the processing of any applicable service fees. At its sole discretion, https://www.rohinimundra.com may use credit card issuer-approved services, such as VISA Account Updater and MasterCard Automatic Billing Updater, to acquire updated payment information for the purpose of processing outstanding payments that are on your account.
<p>https://www.rohinimundra.com may take any reasonable action to validate your payment and registration information, and collect all payments due. You agree to pay all attorney and collection fees arising from any efforts to collect any past due amounts from you, to the extent allowed by law.
<p>Service fees are due at the time of order or on the day of renewal. All fees must be paid in full.
Invoices for all https://www.rohinimundra.com services can be found by logging into your account control panel.
<p>Billing inquiries and disputes should be brought to https://www.rohinimundra.com attention within 30 days of the invoice date. Failure to do so will be deemed to be an admission that the invoice and charges are accurate.
<p>If any chargeback or charge dispute notices are received for your account, services provided to you may be immediately suspended pending investigation, and you will be subject to chargeback service charges. Where applicable, https://www.rohinimundra.com reserves the right to put your domain name into "Registrar Hold" status and deny any transfer requests for that domain name until the chargeback or dispute issue has been resolved.

<h2 id="toc-protection">4. Definition of "No Transaction Fees"</h2>
<p>https://www.rohinimundra.com does not charge you any fees relating to the processing of transactions under your account ("Transaction Fees"). However, your selected payment processor, such as  Payumoney, may still charge you Transaction Fees for each payment you receive. You will be solely responsible for any such Transaction Fees.

<h2 id="toc-content">5. Termination / Plan Change / Refund Policy</h2>
<p>https://www.rohinimundra.com may terminate your Service under the following circumstances (non-exclusive list):
<p>i.	Non-payment of fees
<p>ii.	You are in breach of any term or condition of this Agreement
<p>iii. Your use of the Service disrupts https://www.rohinimundra.com business operations or affects any other party.
<p>All Subscriber data is removed from https://www.rohinimundra.com servers for such terminations.
<p>You may request account termination or hosting plan changes at any time by contacting our Customer Service team either through phone or case ticket. Our contact information can be found on the Support page of our website: http://www.rohinimundra.com/contact-us/.
<p>When submitting your cancellation request, you must provide the correct username and password for your account for verification. Incomplete cancellation requests will be deemed invalid and will not be processed. You will be responsible for any service fees that arise from your failure to cancel your account.
<p>Refunds will not be given for services that are billed monthly or for one-time service fees.


<h2 id="toc-software">6. Subscriber Responsibility</h2>
<p>When you apply to use https://www.rohinimundra.com services, you will be asked to select a Subscriber ID and Password. The Subscriber ID and Password are the means through which you access certain services. You acknowledge and agree that it is your responsibility to safeguard the Subscriber ID and Password you select from any unauthorized use. IN NO EVENT WILL https://www.rohinimundra.com BE LIABLE FOR THE UNAUTHORIZED USE OR MISUSE OF YOUR SUBSCRIBER ID OR PASSWORD.
<p>Subscribers are responsible for maintaining accurate account information at all times, including credit card and contact information. This information can be updated in your account control panel.

<h2 id="toc-modification">7. Prohibited Conduct</h2>
<p>https://www.rohinimundra.com does not allow the use of unsolicited commercial email ("Spam") to promote products or services. Any Subscriber engaging in the sending of Spam through the https://www.rohinimundra.com network or promoting information on websites hosted by https://www.rohinimundra.com will be considered in breach of this Agreement and will be suspended from the Service immediately.
<p>Your use of the Service must be in compliance with Indian government laws at all times.
<p>You are responsible for ensuring that your use of the Service does not consume excessive system or network resources that disrupts the normal use of the Service through, but not limited to, spawning multiple processes, or consuming excessive amounts of memory, CPU or bandwidth capacity.
<p>The following is a non-exclusive list of content, and behavior prohibited by the Service:
<p>iv. Content that contains or contains links to: nudity, pornography, adult content, materials with sex or foul language.
<p>v. Content that condones, promotes, contains, or links to wares, cracks, hacks, their associated utilities, or other piracy related information, whether for educational purposes or not.
<p>vi.	Content that has been promoted through the sending of Spam or mail fraud schemes, or pages that promote or condone the sending of Spam. The sending of bulk email originating from our servers mass distributed to unknown recipients soliciting products or services, or of bulk email NOT originating from our servers mass distributed to unknown recipients soliciting products or services relating to a rohinimundra.com account will result in immediate account suspension.
<p>vii. Content that is grossly offensive to the community, including blatant expressions for bigotry, prejudice, racism, hatred or excessive profanity, or to post any obscene, filthy, excessively violent, harassing, or otherwise object able material.
<p>viii. Content or otherwise that exploits children less than 18 years of age.
<p>ix.	Content that sells or promotes any products or services that are unlawful in the location at which the content is posted or received.
<p>x. Content that infringes or violates any copyright, patent, trademark, service mark, trade name, trade secret, or other intellectual property right of any third party.
<p>xi.	Content that promotes mail fraud, multi-level marketing (pyramid) schemes or other illegal or fraudulent activities.
<p>xii. Content that posts or discloses any personally identifying information or private information about any third parties without their express consent.
<p>xiii. Reverse engineering, reverse compiling or otherwise deriving the underlying source code or structure or sequence of any rohinimundra.com service, solution or technology.
<p>xiv. Reverse engineering, reverse compiling or otherwise deriving the underlying source code or structure or sequence of individual passwording of Subscriber Sites (or pages contained therein).
<h2 id="toc-warranties-disclaimers">8. Notices</h2>
<p>You agree that, unless other instructions are posted on https://www.rohinimundra.com’s website, any notices required to be given under this Agreement will be deemed to have been given if delivered by email or fax, or sent by registered mail or by courier to each of the parties in accordance with the most current contact information you have provided to us, and the contact information for rohinimundra.com posted on the https://www.rohinimundra.com website. All notices shall be effective upon receipt, except that email and fax notices shall be effective upon transmission.

<h2 id="toc-liability">9. Privacy</h2>
<p>The https://www.rohinimundra.com Privacy Policy sets out our obligations with respect to the safeguarding, collection and use of Subscribers' personal information. The https://www.rohinimundra.com/privacy_policy.html is subject to modification from time to time, and such changes are effective upon posting of the modified policy to this URL: https://www.rohinimundra.com/privacy_policy.html
<p>Email newsletters will only be sent directly by https://www.rohinimundra.com. Subscriber information will not be disclosed or sold to any third parties. You may also be contacted by https://www.rohinimundra.com's designated customer review software provider for customer experience and service feedback.

<h2 id="toc-business-uses">10. Reservation of Rights</h2>
<p>https://www.rohinimundra.com reserves the right and sole discretion to:
<p>xv.	Censor any website hosted on its servers that is deemed inappropriate.
<p>xvi. Review any account for excessive space or bandwidth utilization and to suspend service to those accounts that have exceeded allowed levels.
<p>xvii. Terminate any account for non-payment of fees, for providing fraudulent account information or fraudulent payment information.
<p>xviii. Terminate any account if the contents of its website results in, or are the subject of, legal action or threatened legal action against rohinimundra.com or any of its affiliates or partners, without consideration for whether such legal action or threatened legal action is eventually determined to be with or without merit.
<p>xix. Terminate any account for unsolicited, commercial e-mailing (i.e., Spam), illegal access to other computers or networks (i.e., hacking), distribution of Internet viruses or similar distructive activities, activities whether lawful or unlawful that rohinimundra.com determines to be harmful to its other customers, operations or reputation, or for any breach of this agreement.
<p>xx.	Suspend the Service at any time for any duration of time when necessary, without penalty or liability to ourselves.
<p>You agree that it may be necessary for us to temporarily suspend the Service for technical reasons or to maintain network equipment or facilities.
<h2 id="toc-about">11. Limitation of Liability.</h2>
<p>The Service is provided on an "as is" and "as available" basis and the use of the Service is at your own risk. https://www.rohinimundra.com makes no representations or warranties, either expressed or implied, with respect to the Service, or any service or information provided through the Service. https://www.rohinimundra.com is not responsible for any damages, injury or economic loss arising from the use of the content or Service provided by https://www.rohinimundra.com
<p>In no event will https://www.rohinimundra.com be liable to you for any direct, indirect, incidental or consequential damages or economic loss arising out of the Service or in connection with your website or any other services or products provided to you.
<p>https://www.rohinimundra.com, its officers, directors, owners, agents and employees shall in no way be liable to you or anyone else for any loss or injury resulting from the use of the Service or of your website.
<p>In no event shall https://www.rohinimundra.com be held liable for any damages or economic loss, whatsoever, as a result of notifying any official of potentially illegal content on your website, or for providing copies of your data files to the appropriate authorities or cooperating with law enforcement efforts to locate persons who have posted content that is illegal or promotes illegal conduct.
<h2 id="toc-about">12. Indemnification.</h2>
<p>You agree to indemnify and hold https://www.rohinimundra.com, its affiliates, sponsors, partners, directors, officers and employees harmless from and against, and to reimburse https://www.rohinimundra.com with respect to, any and all losses, damages, liabilities, claims, judgments, settlements, fines, costs and expenses (including reasonable related expenses, legal fees, costs of investigation) arising out of or relating to your breach of this Agreement or use by you or any third party of the Services.
<h2 id="toc-about">13. Force Majeure.</h2>
<p>https://www.rohinimundra.com will not be liable for any delay, interruption or failure in the provisioning of services if caused by acts of God, declared or undeclared war, fire, flood, storm, slide, earthquake, power failure, the inability to obtain equipment, supplies or other facilities that are not caused by a failure to pay, labor disputes, or other similar events beyond our control that may prevent or delay service provisioning.

<h2 id="toc-about">14. Unenforceable Provisions.</h2>
<p>If any part of this Agreement is found to be invalid or unenforceable under applicable law, such part will be ineffective to the extent of such invalid or unenforceable part only, without affecting the remaining parts of this Agreement in any way.
<h2 id="toc-about">15. Governing Law</h2>
<p>The rights and obligations of the parties pursuant to this Agreement are governed by, and shall be construed in accordance with, the laws of the province of Indian government and the federal laws of India.
<p>You may be subject to other local, provincial or state and national laws. You hereby irrevocably submit to the exclusive jurisdiction of the Courts of the Province of Indian government for any dispute arising under or relating to this Agreement and waive your right to institute legal proceedings in any other jurisdiction. We shall be entitled to institute legal proceedings in connection with any matter arising under this Agreement in any jurisdiction where you reside, do business or have assets.

<h2 id="toc-about">16. Age of Majority</h2>
<p>https://www.rohinimundra.com does not accept agreements and payments from persons under the legal age of 18 years. By submitting your account application, you confirm that you are over 18 years of age or your parent or legal guardian has agreed to accept this Agreement on your behalf.
<h2 id="toc-about">17. Waiver</h2>
<p>No waiver of any of the provisions of this Agreement will be deemed to constitute a waiver of any other provision nor shall such a waiver constitute a continuing waiver unless otherwise expressly provided in writing duly executed by the party to be bound thereby.
<h2 id="toc-about">18. Entire Agreement</h2>
<p>This Agreement, as may be updated from time to time and posted at http://www.rohinimundra.com/terms_condition.html, represents the complete agreement and understanding between us with respect to the Service and supersedes any other written or oral agreement.<br>
<form class="form-horizontal" role="form"  method="post" action="" onSubmit="return check();">
<input type="checkbox" name="terms" value="check" id="agree" required /> I have read and agree to the Terms and Conditions and Privacy Policy<br><br>
<input type="submit" name="submit" value="Submit" style="background-color:#0C6; color:#fff; font-size:18px; padding-top:8px; padding-bottom:8px; width:10%;" />
</a><a href="customer_logout.php"></a></form>
<br><br><br>



</div></div>


<script src="terms/maia.js"></script>