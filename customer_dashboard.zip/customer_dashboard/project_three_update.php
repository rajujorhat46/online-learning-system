<?php
session_start();
$username=$_SESSION['login'];
include("connection.php");
extract($_POST);



$qry=mysql_query("update project_three SET id='$id',certainity_one='$certainity_one',certainity_two='$certainity_two', significance_one='$significance_one',significance_two='$significance_two',connection_one='$connection_one',connection_two='$connection_two',contribution_one='$contribution_one',contribution_two='$contribution_two',variety_one='$variety_one',variety_two='$variety_two',growth_one='$growth_one',growth_two='$growth_two',action_one='$action_one',relation_one='$relation_one',identity_one='$identity_one',action_two='$action_two',relation_two='$relation_two',identity_two='$identity_two',action_three='$action_three',relation_three='$relation_three',identity_three='$identity_three',action_four='$action_four',relation_four='$relation_four',identity_four='$identity_four',action_five='$action_five',relation_five='$relation_five',identity_five='$identity_five',action_six='$action_six',relation_six='$relation_six',identity_six='$identity_six',completed='1' where id='$id'")or die(mysql_error());
if($qry)
{
//to calculate  the marks
//get the reference data
$q=mysql_query("SELECT * FROM reference where table_name='projectthree'");
$referenceData = mysql_fetch_assoc($q, MYSQL_ASSOC);

//check if marks data already exist
$mQuery=mysql_query("SELECT * FROM marks where login='$username' and table_name='projectthree'");
if(!mysql_fetch_array($mQuery)){
  //insert the marks according to reference
  $business = $referenceData['business'];
  $pLife = $referenceData['professional_life'];
  $selfValue = $referenceData['self_value'];
  $relationships = $referenceData['relationships'];
  $total = ($business + $pLife + $selfValue + $relationships) * 5;
  mysql_query("insert into marks(login, table_name, business, professional_life, self_value, relationships, total) VALUES ('$username', 'projectthree', '$business', '$pLife', '$selfValue', '$relationships', '$total')")or die(mysql_error());
}

  header('Location: project_three_marks.php');
}
else
{
	print mysql_error();
}
?>
