<?php 
session_start();
$username=$_SESSION['login'];
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not CUSTOMER. <a href='https://www.rohinimundra.com/customer_dashboard/customer_login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>


<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

.button {
    background-color: #51A351; 
    border: none;
    color: white;
    padding: 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button1 {border-radius: 4px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 4px;}
.button4 {border-radius: 4px;}
.button5 {border-radius: 4px;}
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header">
<img src="img/TXY logo.png" style="width:220px; height:80px;"> 
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
   <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
      
       <?php
			  include_once "connection.php";
			  
			$result=mysql_query("select * from customer_form where login='$username'");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
         <li><a href="customer_form_view.php?s_no='. $row['s_no'] . '"><i class="icon-user"></i> My Profile</a></li>
        <?php
				  }
			  }
	      
		  ?>
       
        
        <li class="divider"></li>
        <li><a href="customer_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
   
    <li class="" style="margin-left:800px; margin-top:1px;"><a title="" href="customer_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></l
  </ul>
</div>
<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="customer.php" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
   <?php 
      $query_3="SELECT
(SELECT count(*) FROM project_one WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') AS p1,
(SELECT count(*) FROM project_two_step_five WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p2,
(SELECT count(*) FROM project_three WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p3,
(SELECT count(*) FROM bonus_project_one_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p4,
(SELECT count(*) FROM bonus_project_two_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p5,
(SELECT count(*) FROM bonus_project_three_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p6,
(SELECT count(*) FROM bonus_project_four_day_seven WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p7";
  		$query_3_run=mysql_query($query_3);
		//var_dump($query_3_run);
  		if ($query_3_run) {
			
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$p1 = $dbRow['p1'];
					$p2 = $dbRow['p2'];
					$p3 = $dbRow['p3'];
					$p4 = $dbRow['p4'];
					$p5 = $dbRow['p5'];
					$p6 = $dbRow['p6'];
					$p7 = $dbRow['p7'];
  					?>
    <li class="active" data-step="1" data-intro="Find all elements at a glance"><a href="customer.php"><img src="img/icon/32/home.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Dashboard</span></a> </li>
   <li class="submenu"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;TXY-Library<span class="label label-important"></span></a>
      <ul>
        <li><a href="ebook.php"  >Ebook PDF File</a></li>
     </ul>
    </li>
       
        <li class="submenu" > <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>My Progress</span> <span class="label label-important"></span></a>
      <ul>
       <?php 
      $query_5="SELECT * FROM project_one where login='$username' and completed='1'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
      
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="progress_chart.php">My Progress</a></li>
        <?php }
  }
   }
 ?> 
      </ul>
    </li>
            
 
   
        <li class="submenu" > <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Level Zone One</span> <span class="label label-important"></span></a>
               
      <ul>
       <li><a href="project_one.php">Level Zone One</a></li>
         

         <?php 
      $query_5="SELECT * FROM project_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_file.php">Level Zone One File</a></li>
        <?php 
 }
  }
   }
 ?>
</ul>
    </li>
     
          <?php 
	if($p1=='0'){
		echo' <li class="submenu"> <a href="" title="This project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Level Zone Two</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp;<span>Level Zone Two</span> <span class="label label-important"></span></a>';
			}
	?>
      <ul>
        <li style="display:<?php if($p1=='0'){ echo 'none'; } else{ echo ''; } ?>;"><a href="project_two.php">Level Zone Two</a></li>
       
      </ul>
    </li>
    
     <?php 
	if($p2=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Level Zone Three</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Level Zone Three</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
     
    <ul>
        <li><a href="project_three.php">Level Zone Three</a></li>
         <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_three_file.php">Level Zone Three File</a></li>
                                  <?php 
 }
  }
   }
 ?>
         
       </ul>
    </li>
    
      <li class="submenu"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Silver Project</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Silver Project</a></li>
  
        <li><a href="bonus_project_one_upload.php">Silver Project One Upload</a></li>
       </ul>
    </li>
    
    
    
    <?php 
	if($p4=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Gold Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Label Zone Three</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_two.php">Gold Project</a></li>
         <li><a href="bonus_project_two_upload.php">Gold Project Upload</a></li>
       </ul>
    </li>
    
    
    
    <?php 
	if($p5=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Platinum Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Platinum Project</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
      <ul>
        <li><a href="bonus_project_three.php">Platinum Project</a></li>
        <li><a href="bonus_project_three_upload.php">Platinum Project Upload</a></li>
       </ul>
    </li>
  
    
    
     <?php 
	if($p6=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Ruby Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Ruby Project</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_four_day_one.php">Day One</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_one_file.php">Day One File</a></li>
                                         <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_four_day_two.php">Day Two</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_two_file.php">Day Two File</a></li>
                                                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_three_file.php">Day Three File</a></li>
                                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_four_file.php">Day Four File</a></li>
          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_five.php">Day Five</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_five_file.php">Day Five File</a></li>
               <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_six.php">Day Six</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_six_file.php">Day Six File</a></li>
                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_seven.php">Day Seven</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_seven where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_seven_file.php">Day Seven File</a></li>
                        <?php 
 }
  }
   }
 ?>
       
      </ul>
    </li>
    
    <?php 
	if($p6=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Diamond Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Diamond Project</span> <span class="label label-important"></span></a>';
			}
	?>
   <ul>
        <li><a href="bonus_project_five_day_one.php">Day One</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_one_file.php">Day One File</a></li>
                                <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_five_day_two.php">Day Two</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_two_file.php">Day Two File</a></li>
                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_three_file.php">Day Three File</a></li>
                                                    <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_four_file.php">Day Four File</a></li>
                                                             <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_five.php">Day Five</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_five_file.php">Day Five File</a></li>
                                                                       <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_six.php">Day Six</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_six_file.php">Day Six File</a></li>
         <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_seven.php">Day Seven</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
           <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_seven_file.php">Day Seven File</a></li>
                   <?php 
 }
  }
   }
 ?>
       
       
      </ul>
    </li>
  
   <?php
  				}
  			}
  		}
  	 ?>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> </a></div>
  <h1>Project II – Design Your Destiny Board</h1>
  <p style="font-size:18px; font-weight:200; padding-left:15px; padding-right:10px;">I.	Go through every step one by one to design your Destiny Board.</p>
  <p style="font-size:18px; font-weight:200; padding-left:15px; padding-right:10px;">II.	Once you have designed your destiny board post the new destiny board on the TXY group.</p>
  <p style="font-size:18px; font-weight:200; padding-left:15px; padding-right:10px;">III. Put up the Destiny Board on your wall/cupboard.</p><br>
  <h1 style="color:#000;">How to make a Destiny board in 5 steps:</h1>
  <p style="font-size:18px; font-weight:200; padding-left:15px; padding-right:10px;">A Destiny board is a tool used to help clarify, concentrate and maintain focus on a specific life goal. Literally, a destiny board is any sort of board on which you display images that represent whatever you want to be, do or have in your life.</p>
  <h1 style="color:#000;">Step 1: </h1>
  <p style="font-size:18px; font-weight:200; padding-left:15px; padding-right:10px;">Go through your magazines and tear the images from them. No gluing yet! Just let yourself have lots of fun looking through magazines and pulling out pictures or words or headlines that strike your fancy. Have fun with it. Make a big pile of images and phrases and words.</p><br><br>
  <form class="" role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:47%; padding-top:10px; padding-bottom:10px; margin-left:300px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details"></textarea>
 <label style="margin-left:160px;">Upload Images : <span class="require">*</span></label>
 <div style="margin-left:160px;"><input class="cc" type="file" name="picture" style="margin-left:200px;"></div>
     <br><br>
<button type="submit" class="btn btn-default submit" value="Upload news" name="submit" id="submit" style="background-color:#28B779; border-radius:5; width:20%; color:#FFF; padding-top:5px; padding-bottom:5px; margin-left:160px;">Upload</button>
              </form>
</div>
<div class="container-fluid">
 <div class="row-fluid" style="margin-top:50px;">
   <p style="color:#000; font-size:28px;">Step 2: </p><br>
  <p style="font-size:18px; font-weight:200; padding-right:10px;">Go through the images and begin to lay your favorites on the board. Eliminate any images that no longer feel right. This step is where your intuition comes in. As you lay the pictures on the board, you’ll get a sense how the board should be laid out. For instance, you might assign a theme to each corner of the board. Health, Job, Spirituality, Relationships, for instance. Or it may just be that the images want to go all over the place. Or you might want to fold the board into a book that tells a story. At my retreats, I’ve seen women come up with wildly creative ways to present a destiny board.</p><br>
  <form class="" role="form" action="project_two_step_two_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:49%; padding-top:10px; padding-bottom:10px; margin-left:280px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details"></textarea>
 <label style="margin-left:160px;">Upload Images : <span class="require">*</span></label>
 <div style="margin-left:160px;"><input class="cc" type="file" name="picture" style="margin-left:200px;"></div>
     <br><br>
<button type="submit" class="btn btn-default submit" value="Upload news" name="submit_one" id="submit_one" style="background-color:#28B779; border-radius:5; width:20%; color:#FFF; padding-top:5px; padding-bottom:5px; margin-left:160px;">Upload</button>
              </form></div>
              <div class="container-fluid">
 
  <div class="row-fluid" style="margin-top:50px;">
   <div style="margin-left:-20px;">
   <p style="color:#000; font-size:28px; margin-right:300px;">Step 3: </p><br>
  <p style="font-size:18px; font-weight:200; padding-right:10px;">Glue everything onto the board. Add writing if you want. You can paint on it, or write words with markers.</p></div><br>
  <form class="" role="form" action="project_two_step_three_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:51%; padding-top:10px; padding-bottom:10px ;margin-left:260px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details"></textarea>
 <label style="margin-left:160px;">Upload Images : <span class="require">*</span></label>
 <div style="margin-left:160px;"><input class="cc" type="file" name="picture" style="margin-left:200px;"></div>
     <br><br>
<button type="submit" class="btn btn-default submit" value="Upload news" name="submit_two" id="submit_two" style="background-color:#28B779; border-radius:5; width:20%; color:#FFF; padding-top:5px; padding-bottom:5px; margin-left:160px;">Upload</button>
              </form></div>
               <div class="container-fluid">
 
  <div class="row-fluid" style="margin-top:50px;">
  <div style="margin-left:-40px;">
   <p style="color:#000; font-size:28px;">Step 4: </p><br>
  <p style="font-size:18px; font-weight:200; padding-right:10px;">(optional, but powerful) Leave space in the very center of the destiny board for a fantastic photo of yourself where you look radiant and happy. Paste yourself in the center of your board.</p></div><br>
   <form class="" role="form" action="project_two_step_four_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:53%; padding-top:10px; padding-bottom:10px; margin-left:240px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details"></textarea>
 <label style="margin-left:160px;">Upload Images : <span class="require">*</span></label>
 <div style="margin-left:160px;"><input class="cc" type="file" name="picture" style="margin-left:200px;"></div>
     <br><br>
<button type="submit" class="btn btn-default submit" value="Upload news" name="submit_three" id="submit_three" style="background-color:#28B779; border-radius:5; width:20%; color:#FFF; padding-top:5px; padding-bottom:5px; margin-left:160px;">Upload</button>
              </form></div>
              <div class="container-fluid">
 
  <div class="row-fluid" style="margin-top:50px;">
  <div style="margin-left:-60px;">
  <p style="color:#000; font-size:28px;">Step 5: </p><br>
<p style="font-size:18px; font-weight:200; padding-right:10px;">Hang your destiny board in a place where you will see it often</p>
      </div><br> <form class="" role="form" action="project_two_step_five_insert.php" method="post" enctype="multipart/form-data">
<div style="border-color: #000; border-style: dotted; width:55%; padding-top:10px; padding-bottom:10px; margin-left:220px;">
 <label style="margin-left:160px;">Details : <span class="require">*</span></label>
      <textarea style="width:300px; margin-left:160px;"  name="details" id="details"></textarea>
 <label style="margin-left:160px;">Upload Images : <span class="require">*</span></label>
 <div style="margin-left:160px;"><input class="cc" type="file" name="picture" style="margin-left:200px;"></div>
 <input type="hidden" class="span11" id="day" name="day" value="<?php echo date("Y-m-d") ?>" required>
     <br><br>
<button type="submit" class="btn btn-default submit" value="Upload news" name="submit_four" id="submit_four" style="background-color:#28B779; border-radius:5; width:20%; color:#FFF; padding-top:5px; padding-bottom:5px; margin-left:160px;">Upload</button>
              </form></div>
              <?php
	
?>
<?php
?>
   <?php
include("connection.php");
if(isset($_POST['submit']))
{
	function UploadOne($fname)
{
$uploaddir = '/home/rohinimundra/public_html/admin_dashboard/project_two_set_one/';
if (is_uploaded_file($fname['tmp_name']))
{
$filname = basename($fname['name']);
$uploadfile = $uploaddir . basename($fname['name']);
if (move_uploaded_file ($fname['tmp_name'], $uploadfile))
{
	
	
}
else
$res = "Could not move ".$fname['tmp_name']." to ".$uploadfile."<br>";
}
else
$res = "File ".$fname['name']." failed to upload.";

}
	
	if ($_FILES['picture']['name'] != "")	
{
$res = UploadOne($_FILES['picture']);
$filname = $_FILES['picture']['name'];
echo ($res);

}

	
		$dt = time();
		$ip = $_SERVER['REMOTE_ADDR'];
		$timezone = "Asia/Calcutta";
		if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
		$time=date('g:i a');
	

$details=$_POST["details"];
$username=$_SESSION['login'];


	{
$qry=mysql_query("insert into  project_two_step_one(login,upload,details,image_name) values('$username','project_two_set_two','$details','$filname')");

	}
	
	$qry="<font color='green'>Notice added Successfully</font>";
	 echo ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('Your file has been successfully updated THANK YOU')
        window.location.href='project_two.php'
        </SCRIPT>");	
	}



?>       

    </div>
  </div>
 

<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
