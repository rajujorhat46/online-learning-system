<?php 
session_start();
$username=$_SESSION['login'];
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not CUSTOMER. <a href='https://www.rohinimundra.com/customer_dashboard/customer_login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>


<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

.button {
    background-color: #51A351; 
    border: none;
    color: white;
    padding: 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button1 {border-radius: 4px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 4px;}
.button4 {border-radius: 4px;}
.button5 {border-radius: 4px;}
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
.cc{ background-color:#000;}
</style>
</head>
<body>

<!--Header-part-->
<div id="header">
<img src="img/TXY logo.png" style="width:220px; height:80px;"> 
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
   <li  class="" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
     
    </li>
   
    <li class="" style="margin-left:800px; margin-top:1px;"><a title="" href="customer_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></l
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar" style="background-color: #2E363F";><a href="customer.php" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul style="background-color: #2E363F";>
   <?php 
      $query_3="SELECT
(SELECT count(*) FROM project_one WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') AS p1,
(SELECT count(*) FROM project_two_step_five WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p2,
(SELECT count(*) FROM project_three WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p3,
(SELECT count(*) FROM bonus_project_one_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p4,
(SELECT count(*) FROM bonus_project_two_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p5,
(SELECT count(*) FROM bonus_project_three_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p6,
(SELECT count(*) FROM bonus_project_four_day_seven WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p7";
  		$query_3_run=mysql_query($query_3);
		//var_dump($query_3_run);
  		if ($query_3_run) {
			
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$p1 = $dbRow['p1'];
					$p2 = $dbRow['p2'];
					$p3 = $dbRow['p3'];
					$p4 = $dbRow['p4'];
					$p5 = $dbRow['p5'];
					$p6 = $dbRow['p6'];
					$p7 = $dbRow['p7'];
  					?>
  
  
  					
    <li class="active" data-step="1" data-intro="Find all elements at a glance"><a href="customer.php"><img src="img/icon/32/home.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Dashboard</span></a> </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;Help<span class="label label-important"></span></a>
      <ul>
        <li><a href="help.php"  >Help</a></li>
     </ul>
    </li>
    
   <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;TXY-Library<span class="label label-important"></span></a>
      <ul>
        <li><a href="eb_1.php"  >TXY Libarary</a></li>
     </ul>
    </li>
       
        <li class="submenu" style="background-color: #2E363F;" > <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>My Progress</span> <span class="label label-important"></span></a>
      <ul>
       <?php 
      $query_5="SELECT * FROM project_one where login='$username' and completed='1'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
      
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="progress_chart.php">My Progress</a></li>
        <?php }
  }
   }
 ?> 
      </ul>
    </li>
            
 
   
        <li class="submenu" style="background-color: #2E363F;" ><a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span> Zone One </span> <span class="label label-important"></span></a>
               
      <ul>
       
       <li><a href="project_one.php">Zone One</a></li>
               
 <?php 
      $query_5="SELECT * FROM project_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?> 
       
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_file.php">Zone One File</a></li>
        <?php 
 }
  }
   }
 ?>
</ul>
    </li>
          <?php 
	if($p1=='0'){
		echo' <li class="submenu" style="background-color: #2E363F;"> <a href="" title="This project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Zone Two</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu" style="background-color: #2E363F;"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp;<span>Zone Two</span> <span class="label label-important"></span></a>';
			}
	?>
      <ul>
        <li style="display:<?php if($p1=='0'){ echo 'none'; } else{ echo ''; } ?>;"><a href="project_two.php">Zone Two</a></li>
       
      </ul>
    </li>
    
     <?php 
	if($p2=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Zone Three</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Zone Three</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
     
    <ul>
        <li><a href="project_three.php">Zone Three</a></li>
         <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_three_file.php">Zone Three File</a></li>
                                  <?php 
 }
  }
   }
 ?>
         
       </ul>
    </li>
    
    
   
   
    <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Zone Four</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Five</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Zone Six</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Seven</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Eight</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp;&nbsp;  <span>Zone Nine</span> <span class="label label-important"></span></a>
      
    </li>
     <li class="submenu" style="background-color: #2E363F;"> <a href=""><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Zone Ten</span> <span class="label label-important"></span></a>
      
    </li>
    

    
      <li class="submenu" style="background-color: #2E363F;" ><a href="" title="This project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span> Bonus Project One </span> <span class="label label-important"></span></a>
    
      <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
  
        <li><a href="bonus_project_one_upload.php">Bonus Project One Upload</a></li>
       </ul>
                                         <?php 
 }
  }
   }
 ?>
    </li>
    
    
    
    <?php 
	if($p4=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Two</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Two</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
         <li><a href="bonus_project_two_upload.php">Bonus Project Two Upload</a></li>
       </ul>
    </li>
    
    
    
    <?php 
	if($p5=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Three</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Three</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
        <li><a href="bonus_project_three_upload.php">Bonus Project Three Upload</a></li>
       </ul>
    </li>
  
    
    
     <?php 
	if($p6=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Four</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Four</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_four_day_one.php">Day One</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_one_file.php">Day One File</a></li>
                                         <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_four_day_two.php">Day Two</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_two_file.php">Day Two File</a></li>
                                                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_three_file.php">Day Three File</a></li>
                                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_four_file.php">Day Four File</a></li>
          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_five.php">Day Five</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_five_file.php">Day Five File</a></li>
               <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_six.php">Day Six</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_six_file.php">Day Six File</a></li>
                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_seven.php">Day Seven</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_seven where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_seven_file.php">Day Seven File</a></li>
                        <?php 
 }
  }
   }
 ?>
       
      </ul>
    </li>
    
    <?php 
	if($p6=='0'){
		echo' <li style="background-color: #2E363F;"> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Bonus Project Five</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li style="background-color: #2E363F;" class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Bonus Project Five</span> <span class="label label-important"></span></a>';
			}
	?>
   <ul>
        <li><a href="bonus_project_five_day_one.php">Day One</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_one_file.php">Day One File</a></li>
                                <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_five_day_two.php">Day Two</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_two_file.php">Day Two File</a></li>
                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_three_file.php">Day Three File</a></li>
                                                    <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_four_file.php">Day Four File</a></li>
                                                             <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_five.php">Day Five</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_five_file.php">Day Five File</a></li>
                                                                       <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_six.php">Day Six</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_six_file.php">Day Six File</a></li>
         <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_seven.php">Day Seven</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
           <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_seven_file.php">Day Seven File</a></li>
                   <?php 
 }
  }
   }
 ?>
       
       
      </ul>
    </li>
  
   <?php
  				}
  			}
  		}
  	 ?>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb" style="background-color:#9C27B0;"> </div>
  <h1 align="center" style="font-family: Arial, Helvetica, sans-serif; color:#000;">Project One</h1>
  <p align="center" style="font-family: Arial, Helvetica, sans-serif; font-size:22px; color: #000; font-weight:600;">"Goals</span> Make Your Dream Into Dreams Into Reality" </p><br>
  <p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px; font-family: Arial, Helvetica, sans-serif;" align="justify">I.	Whether you want to achieve financial goals, personal goals, health goals, or family goals; this design takes a long-term approach to your goals and then puts them into short term goals.</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px; font-family: Arial, Helvetica, sans-serif;" align="justify">II.	At the 3 month level:  The design asks you to identify your goals both personally, professionally, financially, and other over the next 3 months. What actions will support these goals.</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px; font-family: Arial, Helvetica, sans-serif;" align="justify">III.	At the 2 month level: Now that you know what you want to achieve in 3 months, what do you need to do in 2 months to achieve this. It then asks you what actions support your goals?</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px; font-family: Arial, Helvetica, sans-serif;" align="justify">IV.	At the 1 month level: Now that you know what you want to achieve in 2 months, what do you need to do professionally, personally, or financially; to achieve this. What action steps do you need to take.</p>

<p style="font-size:18px; color:#000; font-weight:300; margin-left:15px; padding-right:50px; font-family: Arial, Helvetica, sans-serif;" align="justify">V.	Once you have the goals and the action steps in place, focus on executing the actions to achieve the goals.
</p>
</div>
<div class="container-fluid">
  <hr class="cc" >
    

  <br><br><div class="row-fluid" style="margin-top:-30px;">
 <p style="font-size:24px; color:#000; font-family: Arial, Helvetica, sans-serif;" align="center">1 Month Level</p> 
<form class="form-horizontal" role="form"  method="post" action="project_one_insert.php">

    <div class="span12">
      <div class="widget-box">
       
        
        <div class="widget-content nopadding">
         
           <div style="overflow-x:auto;">
 
    <table border="1">
  <tr style="background-color:#27A9E3;">
      <th align="center" style="font-size:26px; font-weight:600; font-family:'Comic Sans MS', cursive; font-style:italic;  color:#fff; padding-top:20px; padding-bottom:20px;"><p align="center">AREAS</p></th>
      <th style="font-size:26px; font-weight:600; color:#fff; font-family:'Comic Sans MS', cursive; font-style:italic;  padding-top:20px; padding-bottom:20px;"><p align="center">GOAL</p></th>
      <th style="font-size:26px; font-weight:600; color:#fff; font-family:'Comic Sans MS', cursive; font-style:italic;  padding-top:20px; padding-bottom:20px;"><p align="center">ACTION STEPS</p></th>
    </tr>
   
   
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Personally</p> </td>
      <td width="170px"><textarea class="span11" name="personally_goal_one" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="personally_action_one" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="personally_goal_two" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="personally_action_two" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Professionally</p> </td>
      <td width="170px"><textarea class="span11" name="professionally_goal_one" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="professionally_action_one" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="professionally_goal_two" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="professionally_action_two" placeholder="Write your answer here" ></textarea></td>
     </tr>
     
      <tr>
      <td style="color:#000; " width="px"><p align="center"  style="font-size:18px;">Financially</p> </td>
      <td width="170px"><textarea class="span11" name="financially_goal_one" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="financially_action_one" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="financially_goal_two" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="financially_action_two" placeholder="Write your answer here" ></textarea></td>
     </tr>
     
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Other</p> </td>
      <td width="170px"><textarea class="span11" name="other_goal_one" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="other_action_one" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="other_goal_two" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="other_action_two" placeholder="Write your answer here" ></textarea></td>
     </tr>
 </table>
</div>
             
              
             
                        
           <div style="overflow-x:auto; "><br>
 <p style="font-size:24px; font-family: Arial, Helvetica, sans-serif; color:#000;" align="center">2 Month Level</p> 
    <table border="1">
  <tr style="background-color: #27A9E3;">
      <th style="font-size:26px; font-weight:600; font-family:'Comic Sans MS', cursive; font-style:italic;  color:#fff; padding-top:20px; padding-bottom:20px;"><p align="center">AREAS</p></th>
      <th style="font-size:26px; font-weight:600; color:#fff; font-family:'Comic Sans MS', cursive; font-style:italic;  padding-top:20px; padding-bottom:20px;"><p align="center">GOAL</p></th>
      <th style="font-size:26px; font-weight:600; color:#fff; font-family:'Comic Sans MS', cursive; font-style:italic;  padding-top:20px; padding-bottom:20px;"><p align="center">ACTION STEPS</p></th>
    </tr>
   
   
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Personally</p> </td>
      <td width="170px"><textarea class="span11" name="personally_goal_one1" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="personally_action_one1" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="personally_goal_two1" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="personally_action_two1" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Professionally</p> </td>
      <td width="170px"><textarea class="span11" name="professionally_goal_one1" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="professionally_action_one1" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="professionally_goal_two1" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="professionally_action_two1" placeholder="Write your answer here" ></textarea></td>
     </tr>
     
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Financially</p> </td>
      <td width="170px"><textarea class="span11" name="financially_goal_one1" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="financially_action_one1" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="financially_goal_two1" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="financially_action_two1" placeholder="Write your answer here" ></textarea></td>
     </tr>
     
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Other</p> </td>
      <td width="170px"><textarea class="span11" name="other_goal_one1" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="other_action_one1" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="other_goal_two1" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="other_action_two1" placeholder="Write your answer here" ></textarea></td>
     </tr>
 </table>
</div>
<div style="overflow-x:auto;"><br>
 <p style="font-size:24px; color:#000;" align="center">3 Month Level</p> 
    <table border="1">
  <tr style="background-color: #27A9E3;">
      <th style="font-size:26px; font-weight:600; font-style:italic; font-family:'Comic Sans MS', cursive;  color:#fff; padding-top:20px; padding-bottom:20px;"><p align="center">AREAS</p></th>
      <th style="font-size:26px; font-weight:600; color:#fff; font-family:'Comic Sans MS', cursive; font-style:italic;  padding-top:20px; padding-bottom:20px;"><P align="center">GOAL</p></th>
      <th style="font-size:26px; font-weight:600; color:#fff; font-family:'Comic Sans MS', cursive; font-style:italic;  padding-top:20px; padding-bottom:20px;"><p align="center">ACTION STEPS</p></th>
    </tr>
   
   
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Personally</p> </td>
      <td width="170px"><textarea class="span11" name="personally_goal_one2" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="personally_action_one2" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="personally_goal_two2" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="personally_action_two2" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Professionally</p> </td>
      <td width="170px"><textarea class="span11" name="professionally_goal_one2" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="professionally_action_one2" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="professionally_goal_two2" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="professionally_action_two2" placeholder="Write your answer here" ></textarea></td>
     </tr>
     
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Financially</p> </td>
      <td width="170px"><textarea class="span11" name="financially_goal_one2" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="financially_action_one2" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="financially_goal_two2" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="financially_action_two2" placeholder="Write your answer here" ></textarea></td>
     </tr>
     
      <tr>
      <td style="color:#000; " width="px"><p align="center" style="font-size:18px;">Other</p> </td>
      <td width="170px"><textarea class="span11" name="other_goal_one2" placeholder="Write your answer here"></textarea> </td>
      <td width="100px"><textarea class="span11" name="other_action_one2" placeholder="Write your answer here" ></textarea></td>
     </tr>
      <tr>
      <td style="font-size:14px; color:#000;" width="100px"> </td>
      <td width="100px"><textarea class="span11" name="other_goal_two2" placeholder="Write your answer here" ></textarea></td>
      <td width="100px"><textarea class="span11" name="other_action_two2" placeholder="Write your answer here" ></textarea></td>
        <input type="hidden" class="span11" id="day" name="day" value="<?php echo date("Y-m-d") ?>" required>

     </tr>
 </table>
</div>
 <div class="controls"  style="margin-left:10px;">
   <button type="submit" class="btn btn-success" name="submit" >Save</button>
  
              
              </div>
            </div>
            </div></div></div>
     
     
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2018 &copy; Brought to you by <a href="https://www.rohinimundra.com">Rohini Mundra</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
