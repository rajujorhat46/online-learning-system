<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];

$qry=mysql_query("insert into bonus_project_four_day_seven (login, positive_one, impact_one, positive_two, impact_two, positive_three, impact_three, positive_four, impact_four, positive_five, impact_five, day,completed) values('$username','$positive_one', '$impact_one', '$positive_two', '$impact_two', '$positive_three', '$impact_three', '$positive_four', '$impact_four', '$positive_five', '$impact_five','$day','0')")or die(mysql_error());
if($qry)
{
 header('Location: bonus_project_four_day_seven_file.php');
}
else
{
	print mysql_error();
}


?>
