<?php
  session_start();
error_reporting(0);
if($_SESSION['login']){
	
	
}else{
	echo "You Are not CUSTOMER. <a href='https://www.rohinimundra.com/customer_dashboard/customer_login.php'>Go to Login Page</a>";
	die();
}

  
  
    include_once "connection.php";
    if(isset($_GET['id']))
	{
		$id=$_GET['id'];
			  
			  $result=mysql_query("select * from form where id='$id'",$con);
			  $count=mysql_num_rows($result);
			  
			  if($count>0)
			  {
				  while($row=mysql_fetch_assoc($result))
				  {
			  $id=$row['id'];
			  $name=$row['name'];
			  $phone=$row['phone'];
			  $email=$row['email'];
			  $signup_date=$row['signup_date'];
			  $location=$row['location'];
			  $duration=$row['duration'];
			  $payment_type=$row['payment_type'];
			  $payment_one=$row['payment_one'];
			  $payment_one_date=$row['payment_one_date'];
			  $payment_two=$row['payment_two'];
			  $payment_two_date=$row['payment_two_date'];
			  $payment_three=$row['payment_three'];
			  $payment_third_date=$row['payment_third_date'];
		
				  }
			  }else
			  {
			  	echo 'Wrong Input. try again later!! . :( <br><br>';
				echo '<a href="file_search.php">Click here to go Back!</a>';
				die();
			  }
	}else
	{
		
		header("Location:file_search.php");
		die();
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/colorpicker.css" />
<link rel="stylesheet" href="css/datepicker.css" />
<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="customer_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="customer_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="customer.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
  <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>File</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="ebook.php"  >Ebook PDF File</a></li>
     </ul>
    </li>
   
         
              <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_one_month_one.php">One Month Level</a></li>
        <li><a href="project_one_month_one_file.php">One Month Level File</a></li>

        <li><a href="project_one_month_two.php">Two Month Level</a></li>
        <li><a href="project_one_month_two_file.php">Two Month Level File</a></li>
        
        <li><a href="project_one_month_three.php">Three Month Level</a></li>
         <li><a href="project_one_month_three_file.php">Three Month Level File</a></li>
     </ul>
    </li>
      <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_two.php">Project Two</a></li>
        <li><a href="project_two_file.php">Project Two File</a></li>
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="project_three.php">Project Three</a></li>
         <li><a href="project_three_file.php">Project Three File</a></li>
       </ul>
    </li>
    
      <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Bonus Project One</a></li>
        <li><a href="bonus_project_one_upload.php">Bonus Project One Upload</a></li>
       </ul>
    </li>
      <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_two.php">Bonus Project Two</a></li>
         <li><a href="bonus_project_two_upload.php">Bonus Project Two Upload</a></li>
       </ul>
    </li>
      <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Three</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_three.php">Bonus Project Three</a></li>
        <li><a href="bonus_project_three_upload.php">Bonus Project Three Upload</a></li>
       </ul>
    </li>
    
    
    
      <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Four</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_four_day_one.php">Day One</a></li>
        <li><a href="bonus_project_four_day_one_file.php">Day One File</a></li>
        <li><a href="bonus_project_four_day_two.php">Day Two</a></li>
        <li><a href="bonus_project_four_day_two_file.php">Day Two File</a></li>
         <li><a href="bonus_project_four_day_three.php">Day Three</a></li>
         <li><a href="bonus_project_four_day_three_file.php">Day Three File</a></li>
         <li><a href="bonus_project_four_day_four.php">Day Four</a></li>
         <li><a href="bonus_project_four_day_four_file.php">Day Four File</a></li>
         <li><a href="bonus_project_four_day_five.php">Day Five</a></li>
          <li><a href="bonus_project_four_day_five_file.php">Day Five File</a></li>
         <li><a href="bonus_project_four_day_six.php">Day Six</a></li>
          <li><a href="bonus_project_four_day_six_file.php">Day Six File</a></li>
         <li><a href="bonus_project_four_day_seven.php">Day Seven</a></li>
          <li><a href="bonus_project_four_day_seven_file.php">Day Seven File</a></li>
       
       
      </ul>
    </li>
     <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Bonus Project Five</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_five_day_one.php">Day One</a></li>
        <li><a href="bonus_project_five_day_one_file.php">Day One File</a></li>
        <li><a href="bonus_project_five_day_two.php">Day Two</a></li>
          <li><a href="bonus_project_five_day_two_file.php">Day Two File</a></li>
         <li><a href="bonus_project_five_day_three.php">Day Three</a></li>
          <li><a href="bonus_project_five_day_three_file.php">Day Three File</a></li>
         <li><a href="bonus_project_five_day_four.php">Day Four</a></li>
          <li><a href="bonus_project_five_day_four_file.php">Day Four File</a></li>
         <li><a href="bonus_project_five_day_five.php">Day Five</a></li>
          <li><a href="bonus_project_five_day_five_file.php">Day Five File</a></li>
         <li><a href="bonus_project_five_day_six.php">Day Six</a></li>
         <li><a href="bonus_project_five_day_six_file.php">Day Six File</a></li>
         <li><a href="bonus_project_five_day_seven.php">Day Seven</a></li>
           <li><a href="bonus_project_five_day_seven_file.php">Day Seven File</a></li>
       
       
      </ul>
    </li>
       
  
   

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> </a></div>
  <h1>Fill-up the form correctly</h1>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
  
<form class="form-horizontal" role="form"  method="post" action="file_update.php" onSubmit="return check();">
    <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
         
        </div> 
        
        <div class="widget-content nopadding">
          <div class="control-group">
              <label class="control-label">Serial No. : <span class="require">*</span></label>
              <div class="controls">
                
                  <input type="text" class="span11" id="id" name="id" required  value="<?php echo $id ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Name : <span class="require">*</span></label>
              <div class="controls">
                
                  <input type="text" class="span11" id="name" name="name" required  value="<?php echo $name ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Phone : <span class="require">*</span></label>
              <div class="controls">
               <input type="text" class="span11" id="phone" name="phone" required value="<?php echo $phone ;?>" onkeypress='validate(event)'>
                
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Email : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="email" class="span11" id="login" name="login" value="<?php echo $login;?>" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Sign Up Date : <span class="require">*</span></label>
              <div class="controls">
               
                <input type="date" class="span11" id="signup_date" name="signup_date"  value="<?php echo $signup_date ;?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Location : <span class="require">*</span></label>
              <div class="controls">
               
                 <input type="text" class="span11" id="location" name="location" value="<?php echo $location ;?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Duration : <span class="require">*</span></label>
              <div class="controls">
                <input type="text" class="span11" id="duration" name="duration" value="<?php echo $duration ;?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Payment Type : <span class="require">*</span></label>
              <div class="controls">
                <input type="text" class="span11" id="payment_type" name="payment_type" value="<?php echo $payment_type ;?>">
              </div>
            </div>
             </div></div></div>
     
     <div class="span6">
     <div class="widget-box">
     <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          
        </div>
        <div class="widget-content nopadding">

        <div class="control-group">
              <label class="control-label"> Payment Part One : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="text" class="span11" id="payment_one" name="payment_one" value="<?php echo $payment_one ;?>" required onkeypress='validate(event)'>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">First Payment Date : <span class="require">*</span></label>
              <div class="controls">
               <input type="date" class="span11" id="payment_one_date" name="payment_one_date"  value="<?php echo $payment_one_date ;?>" required>
               
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Two :</label>
              <div class="controls">
                 <input type="text" class="span11" id="payment_two" name="payment_two" value="<?php echo $payment_two ;?>" onkeypress='validate(event)'>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Second Payment Date :</label>
              <div class="controls">
                 <input type="date" class="span11" id="payment_two_date" name="payment_two_date" value="<?php echo $payment_two_date ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Three :</label>
              <div class="controls">
                <input type="text" class="span11" id="payment_three" name="payment_three" onkeypress='validate(event)'  value="<?php echo $payment_three ;?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Third Payment Date :</label>
              <div class="controls">
                 <input type="date" class="span11" id="payment_third_date" name="payment_third_date" value="<?php echo $payment_third_date ;?>" required>
              </div>
            </div>
           
         
           
         
          
        </div>
      </div>
     
              <button type="submit" class="btn btn-success">Please check and update</button>
           
      </form>
  
           
   
      
        </div>
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
