<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(isset($_POST['change']))
{
   $email=$_POST['email'];
   $password=md5($_POST['password']);
$query=mysql_query("SELECT * FROM customersetpassword WHERE email='$email'");
$num=mysql_fetch_array($query);
if($num>0)
{
$extra="customer_login.php";
mysql_query("update customersetpassword set password='$password' where email='$email'");
$host=$_SERVER['HTTP_HOST'];
$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
$_SESSION['errmsg']="Password Changed Successfully";
exit();
}
else
{
$extra="forgotpassword.php";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
$_SESSION['errmsg']="Invalid email id";
exit();
}
}

?>


<!DOCTYPE html>
<html lang="en">
    
<head>
        <title>Admin</title><meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="css/matrix-login.css" />
        <link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

    </head>
    <body>
        <div id="loginbox"> 
         <p align="center" style="color:#F00; font-size:18px; font-weight:700;"><?php echo $_SESSION['error1']; ?></p>           
            <form id="loginform" class="form-vertical" role="form" method="post" onSubmit="return valid();">
             
				 <div class="control-group normal_text"> <h3><img src="css/TXY logo.png" alt="Login" /></h3></div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
          <p align="center" style="color:#F00; font-size:18px; font-weight:700;"></p>
                            <span class="add-on bg_lg"><img src="img/client.png"></span><input type="text" placeholder="Email" name="email" style="padding-top:10px; padding-bottom:8px;"  />
                        </div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
 <span class="add-on bg_ly"><img src="img/lock.png"></span><input type="password" placeholder="Password" name="password" style="padding-top:10px; padding-bottom:8px;" />
                        </div>
                    </div>
                </div>
                <div class="" style="margin-right:150px;">
                    
                    <span class="pull-right" style="margin-left:500px;">
                     <button type="submit" class="btn btn-success" name="change"  style="margin-left:500px;">Reset</button></span>
                </div>
            </form>
         
        </div>
        
        <script src="js/jquery.min.js"></script>  
        <script src="js/matrix.login.js"></script> 
    </body>

</html>
