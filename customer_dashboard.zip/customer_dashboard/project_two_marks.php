<?php
session_start();
$username=$_SESSION['login'];
include("connection.php");
extract($_POST);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Learning System</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

<style>
.button {
    background-color: #51A351; 
    border: none;
    color: white;
    padding: 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button1 {border-radius: 4px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 4px;}
.button4 {border-radius: 4px;}
.button5 {border-radius: 4px;}
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #000;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<!--Header-part-->
<div id="header">
<img src="img/TXY logo.png" style="width:220px; height:80px;"> 
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
   <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
      
       <?php
			  include_once "connection.php";
			  
			$result=mysql_query("select * from customer_form where login='$username'");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
         <li><a href="customer_form_view.php?s_no='. $row['s_no'] . '"><i class="icon-user"></i> My Profile</a></li>
        <?php
				  }
			  }
	      
		  ?>
       
        
        <li class="divider"></li>
        <li><a href="customer_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
   
    <li class="" style="margin-left:800px; margin-top:1px;"><a title="" href="customer_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></l
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="customer.php" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
   <?php 
      $query_3="SELECT
(SELECT count(*) FROM project_one WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') AS p1,
(SELECT count(*) FROM project_two_step_five WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p2,
(SELECT count(*) FROM project_three WHERE day <= DATE_SUB(CURDATE(), INTERVAL 10 DAY) and completed=1 and login='$username') as p3,
(SELECT count(*) FROM bonus_project_one_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p4,
(SELECT count(*) FROM bonus_project_two_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p5,
(SELECT count(*) FROM bonus_project_three_customer WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p6,
(SELECT count(*) FROM bonus_project_four_day_seven WHERE day <= DATE_SUB(CURDATE(), INTERVAL 15 DAY) and completed=1 and login='$username') as p7";
  		$query_3_run=mysql_query($query_3);
		//var_dump($query_3_run);
  		if ($query_3_run) {
			
  			if (mysql_num_rows($query_3_run)>0) {
  				while ($dbRow=mysql_fetch_array($query_3_run)) {
					$p1 = $dbRow['p1'];
					$p2 = $dbRow['p2'];
					$p3 = $dbRow['p3'];
					$p4 = $dbRow['p4'];
					$p5 = $dbRow['p5'];
					$p6 = $dbRow['p6'];
					$p7 = $dbRow['p7'];
  					?>
    <li class="active" data-step="1" data-intro="Find all elements at a glance"><a href="customer.php"><img src="img/icon/32/home.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Dashboard</span></a> </li>
   <li class="submenu"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;TXY-Library<span class="label label-important"></span></a>
      <ul>
        <li><a href="ebook.php"  >Ebook PDF File</a></li>
     </ul>
    </li>
       
        <li class="submenu" > <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>My Progress</span> <span class="label label-important"></span></a>
      <ul>
       <?php 
      $query_5="SELECT * FROM project_one where login='$username' and completed='1'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
      
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="progress_chart.php">My Progress</a></li>
        <?php }
  }
   }
 ?> 
      </ul>
    </li>
            
 
   
        <li class="submenu" > <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp; <span>Level Zone One</span> <span class="label label-important"></span></a>
               
      <ul>
       <li><a href="project_one.php">Level Zone One</a></li>
         

         <?php 
      $query_5="SELECT * FROM project_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_one_file.php">Level Zone One File</a></li>
        <?php 
 }
  }
   }
 ?>
</ul>
    </li>
     
          <?php 
	if($p1=='0'){
		echo' <li class="submenu"> <a href="" title="This project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;  <span>Level Zone Two</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp;<span>Level Zone Two</span> <span class="label label-important"></span></a>';
			}
	?>
      <ul>
        <li style="display:<?php if($p1=='0'){ echo 'none'; } else{ echo ''; } ?>;"><a href="project_two.php">Level Zone Two</a></li>
       
      </ul>
    </li>
    
     <?php 
	if($p2=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Level Zone Three</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Level Zone Three</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
     
    <ul>
        <li><a href="project_three.php">Level Zone Three</a></li>
         <?php 
      $query_5="SELECT * FROM project_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="project_three_file.php">Level Zone Three File</a></li>
                                  <?php 
 }
  }
   }
 ?>
         
       </ul>
    </li>
    
      <li class="submenu"> <a href=""><img src="img/icon/list.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Silver Project</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="bonus_project_one.php">Silver Project</a></li>
  
        <li><a href="bonus_project_one_upload.php">Silver Project One Upload</a></li>
       </ul>
    </li>
    
    
    
    <?php 
	if($p4=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Gold Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Label Zone Three</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_two.php">Gold Project</a></li>
         <li><a href="bonus_project_two_upload.php">Gold Project Upload</a></li>
       </ul>
    </li>
    
    
    
    <?php 
	if($p5=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Platinum Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Platinum Project</span> <span class="label label-important"></span></a>';
			}
	?>
    
    
      <ul>
        <li><a href="bonus_project_three.php">Platinum Project</a></li>
        <li><a href="bonus_project_three_upload.php">Platinum Project Upload</a></li>
       </ul>
    </li>
  
    
    
     <?php 
	if($p6=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Ruby Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Ruby Project</span> <span class="label label-important"></span></a>';
			}
	?>
     
      <ul>
        <li><a href="bonus_project_four_day_one.php">Day One</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_one_file.php">Day One File</a></li>
                                         <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_four_day_two.php">Day Two</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_two_file.php">Day Two File</a></li>
                                                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_three_file.php">Day Three File</a></li>
                                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_four_file.php">Day Four File</a></li>
          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_five.php">Day Five</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_five_file.php">Day Five File</a></li>
               <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_six.php">Day Six</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_four_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_six_file.php">Day Six File</a></li>
                 <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_four_day_seven.php">Day Seven</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_four_day_seven where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_four_day_seven_file.php">Day Seven File</a></li>
                        <?php 
 }
  }
   }
 ?>
       
      </ul>
    </li>
    
    <?php 
	if($p6=='0'){
		echo' <li> <a href="" title="This is project is locked" class="tip-bottom"><img src="img/icon/locked.png" style="width:12px; margin-top:-2px;">&nbsp; &nbsp; &nbsp;<span>Diamond Project</span> <span class="label label-important"></span></a>';
		}
		else{
			echo' <li class="submenu"> <a href="" title="" class="tip-bottom"><img src="img/icon/list.png" style="width:12px; margin-top:-2px;"> &nbsp; &nbsp; &nbsp; <span>Diamond Project</span> <span class="label label-important"></span></a>';
			}
	?>
   <ul>
        <li><a href="bonus_project_five_day_one.php">Day One</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_one where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
        <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_one_file.php">Day One File</a></li>
                                <?php 
 }
  }
   }
 ?>
        <li><a href="bonus_project_five_day_two.php">Day Two</a></li>
        <?php 
      $query_5="SELECT * FROM bonus_project_five_day_two where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_two_file.php">Day Two File</a></li>
                                          <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_three.php">Day Three</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_three where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_three_file.php">Day Three File</a></li>
                                                    <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_four.php">Day Four</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_four where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_four_file.php">Day Four File</a></li>
                                                             <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_five.php">Day Five</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_five where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
          <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_five_file.php">Day Five File</a></li>
                                                                       <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_six.php">Day Six</a></li>
          <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
         <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_six_file.php">Day Six File</a></li>
         <?php 
 }
  }
   }
 ?>
         <li><a href="bonus_project_five_day_seven.php">Day Seven</a></li>
         <?php 
      $query_5="SELECT * FROM bonus_project_five_day_six where login='$username'";
  		$query_5_run=mysql_query($query_5);
  		if ($query_5_run) {
  			if (mysql_num_rows($query_5_run)>=0) {
  				while ($dbRow=mysql_fetch_array($query_5_run)) {
  					?>
           <li style="display:<?php if($dbRow['completed']=='0' or $dbRow['completed']=='1'){ echo ''; } else{ echo 'none'; } ?>;"><a href="bonus_project_five_day_seven_file.php">Day Seven File</a></li>
                   <?php 
 }
  }
   }
 ?>
       
       
      </ul>
    </li>
  
   <?php
  				}
  			}
  		}
  	 ?>

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> </a></div>
  <h1>Project Two Remarks</h1><br>
  
</div>
<div class="container-fluid">
  <hr>
  
  <div class="row-fluid">
  


    <div class="span12">
      <div class="widget-box">
       
        
        <div class="widget-content nopadding">
         
           <div style="overflow-x:auto;">
            <?php
			  include_once "connection.php";
			  
			$result=mysql_query("SELECT * FROM marks where login='$username' and table_name='projecttwo'");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
  <table border="1">
  
 <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">Username</td>
      <td><?php echo $username;?></td>
     
     </tr>
      <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">Business</td>
      <td><?php echo $row["business"]; ?></td>
      
     </tr>
      <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">Professional Life</td>
      <td><?php echo $row["professional_life"];  ?></td>
   
     </tr>
      <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">Self Values</td>
      <td><?php echo $row["self_value"];  ?></td>
     
     </tr>
     <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">Relationships</td>
      <td><?php echo $row["relationships"];  ?></td>
     
     </tr>
     <tr>
      <td style="font-size:18px; color:#000; font-weight:600;">Total Marks</td>
      <td><?php echo $row["grand_total"];  ?></td>
     
     </tr>
     
     </table><?php
				  }
			  }
	      
		  ?><br><br>
 </div>
 <div class="controls"  style="margin-left:10px;">
              </div>
            </div>
            </div></div></div>
      </div>
    </div>
  </div>
 
</div></div>


 
 

 
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
