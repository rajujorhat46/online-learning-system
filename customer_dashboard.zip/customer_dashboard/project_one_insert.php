<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];

$duplicate_find="SELECT * from project_one where login='$username'";
$run_duplicate_find=mysql_query($duplicate_find);
if ($run_duplicate_find) 
{
	if (mysql_num_rows($run_duplicate_find)>0) 
	   {
		 die ("<SCRIPT LANGUAGE='JavaScript'>
          window.alert('You had already save the data, please check into your label zone one file for edit and view or click the button below ok.')
        window.location.href='project_one_file.php'
        </SCRIPT>");
	    }
}
else{
	die('Query not Executed.');
}

$qry=mysql_query("insert into project_one(login, personally_goal_one,personally_action_one,personally_goal_two,personally_action_two,professionally_goal_one,professionally_action_one,professionally_goal_two,professionally_action_two,financially_goal_one,financially_action_one,financially_goal_two,financially_action_two,other_goal_one,other_action_one,other_goal_two,other_action_two,personally_goal_one1,personally_action_one1,personally_goal_two1,personally_action_two1,professionally_goal_one1,professionally_action_one1,professionally_goal_two1,professionally_action_two1,financially_goal_one1,financially_action_one1,financially_goal_two1,financially_action_two1,other_goal_one1,other_action_one1,other_goal_two1,other_action_two1,personally_goal_one2,personally_action_one2,personally_goal_two2,personally_action_two2,professionally_goal_one2,professionally_action_one2,professionally_goal_two2,professionally_action_two2,financially_goal_one2,financially_action_one2,financially_goal_two2,financially_action_two2,other_goal_one2,other_action_one2,other_goal_two2,other_action_two2,completed,day)values('$username','$personally_goal_one','$personally_action_one','$personally_goal_two','$personally_action_two','$professionally_goal_one','$professionally_action_one','$professionally_goal_two','$professionally_action_two','$financially_goal_one','$financially_action_one','$financially_goal_two','$financially_action_two','$other_goal_one','$other_action_one','$other_goal_two','$other_action_two','$personally_goal_one1','$personally_action_one1','$personally_goal_two1','$personally_action_two1','$professionally_goal_one1','$professionally_action_one1','$professionally_goal_two1','$professionally_action_two1','$financially_goal_one1','$financially_action_one1','$financially_goal_two1','$financially_action_two1','$other_goal_one1','$other_action_one1','$other_goal_two1','$other_action_two1','$personally_goal_one2','$personally_action_one2','$personally_goal_two2','$personally_action_two2','$professionally_goal_one2','$professionally_action_one2','$professionally_goal_two2','$professionally_action_two2','$financially_goal_one2','$financially_action_one2','$financially_goal_two2','$financially_action_two2','$other_goal_one2','$other_action_one2','$other_goal_two2','$other_action_two2','0','$day')")or die(mysql_error());
if($qry)
{
 header('Location: project_one_file.php');
}
else
{
	print mysql_error();
}


?>
